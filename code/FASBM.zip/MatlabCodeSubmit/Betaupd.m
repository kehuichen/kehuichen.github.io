function [Bnew]= Betaupd(Bold, y,der,mu, addW,linkArg, distriArg)
% It's coded for updating  the  coefficients in FASBM by Fisher scoring method.
% der: size P*N
% Bold: size P*1
% W2 W1: N*N

dataClass = superiorfloat(y);
[~,~,dlink,~] = stattestlink(linkArg,dataClass);
muLims = [eps(dataClass) 1-eps(dataClass)];
if strcmp(distriArg,'Bernoulli')
    if any(mu < muLims(1) | muLims(2) < mu)
        mu = max(min(mu,muLims(2)),muLims(1));
    end
    sigma2 =  mu.*(1-mu);
elseif strcmp(distriArg,'Poisson')
    sigma2 =  mu ;
elseif strcmp(distriArg,'Normal')
    sigma2 = 1 ;
end

N = size(der,2);
w1 = 1./(dlink(mu).*sigma2);
W1 = sparse(1:N,1:N,w1);
w2 = 1./(dlink(mu).^2.*sigma2);
W2  = sparse(1:N,1:N,w2);
 
if isempty(addW)
    addW= ones(N,1);
    addW = sparse(1:N,1:N,addW);
end

Bnew =  Bold+ pinv(der*W2*addW*der')*der*W1*addW*(y-mu);




end
