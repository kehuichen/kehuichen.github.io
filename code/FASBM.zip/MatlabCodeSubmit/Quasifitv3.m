function [xou,muv,mud,idx,center,beta] = Quasifitv3(Xcov, y, m, k, linkArg, distriArg, ftype, method, frac,bw,kernel, nwe, npoly,nder,idx_t,start, reps, maxit, verbose)
% It's coded for  fitting  a feature adjusted stochastic block model (FASBM): g(E(Y_ij)) = C_{rirj) + f(beta*Xcov)
% Input: 
 
%  Xcov:        feature matrix in (m*m)-by-s matrix  
%  y:           network in (m*m)-by-1 matrix 
%  m:           number of nodes
%  k:           number of communities
%  linkArg:     link function,  acceptable values for  linkArg are 'identity', 'logit', 'log' 
%  distriArg:   Distribution,   acceptable values for  distriArg are 'Normal', 'Bernoulli', 'Poisson'.
%  ftype:       f = 0 or f is an unknown smooth function.  Acceptable values are []  or 'non'. 
%  method:      method used for updating labels,  acceptable values are 'LS'  or 'loglikelihood'.  'LS' is least-squares method minimizing
%               the sum of squared residuals. 'loglikelihood' will minimize negative of the sum of loglikelihood

%  frac:        Proportion of xin to subsample in the fitting f step
%  bw:          bandwidth for fitting f
%  kernel :     kernel type
%  nwe          degree of opt polynomial
%  npoly        degree of polynomial
%  nder         order of derivative (npoly-nder=1 in our case)

%  optional inputs
%  idx_t:       True community labels,  unknown by default
%  start:       Initial partition method (K-means, Numeric, or Spectral),  K-means by default
%  reps:        repeat the algorithm reps times to get close to globle  optimal, =1 by default .
%  maxit:       maximum number of iterations between R and {f, C, beta}, =100 by default
%  verbose:     if 'on', print steps on the screen, ='off' by defult


% Output:
%  idx:  returns partition results in m-by-1   matrix
%  xou muv mud: non parametric fit
%  center:   estimated C in k-by-k matrix
%  beta:    estimated beta in  s-by-1 matrix

% Last Update Date:  2017 DEC
% References:
% [1] Y. Zhang, K.H. Chen et. al "Node Features adjusted Stochastic Block Model". 



if nargin == 14;
    idx_t = [];
    start = [];
    reps = [];
    maxit = [];
    verbose = [];
end


if isempty(start)
    start =  'kmeans';
end 
if isempty(reps)
    reps = 1;
end
if isempty(maxit)
    maxit = 100;
end
if isempty(verbose)
    verbose = 'off';
end

 
% Done with input argument processing, begin clustering
for rep = 1:reps
    % Initialize R
    if  isempty(idx_t)
        switch start
            case 'spectral'
                idx = SpectralCluster(reshape(y,m,m), k, 0, k, 200);
            case 'numeric'
                idx = start;
            case 'kmeans'
                if length(size(y))==2 && size(y,2)==1
                    idx = kmeans(reshape(y,m,m), k, 'Replicates', 50);
                end
                if length(size(y))==2 && size(y,2)>1
                    idx = kmeans(y', k, 'Replicates', 50);    % this line deals with rectangular y
                end
        end
        
    else idx = idx_t;
    end
    % Initialize beta
    if  isempty(Xcov)
        beta = 0;
    elseif size(y,2)==1 && ~isempty(Xcov)
        s = size(Xcov,2);
        beta =  repmat(sqrt(1/s),s,1);
    else beta =1 ;    % This line deals with rectangular y
    end
    
    % Done with initialization
    iter = 0;
    CONVERGE = 0;
    prebeta = beta;
    threshold = 1e-4;
  
    
    while  CONVERGE == 0 && iter < maxit
        iter = iter + 1 ;
        if strcmp(verbose, 'on' )
        fprintf([ 'iter = ' num2str(iter) '\n' ]);
        end
        
        %%%%%%%%%%%%%%%%%%%%%%%%
%           updating C R
        %%%%%%%%%%%%%%%%%%%%%%%%
         if  isempty(idx_t)
            if iter==1 && strcmp(ftype, 'non')
                n = size(y,1);
                xin = Pick(Xcov,[], [],[],[]) * beta ;
                rands = randsample(length(xin),floor(length(xin)*frac));
                xou = sort(unique(xin(rands))); %  xou must be sorted , subsampling N points
                win = Pick(ones(n,1),[],[],[],[] );
                yin = Pick(y,[],[],[],[] );
                cin = zeros(size(win));
                [~,muv,~]=LwlsG(bw,kernel,nwe,npoly,nder,xin,yin,win,xou,cin, linkArg,0,distriArg );
                muv = muv- interp1(xou, muv,floor(mean(xou)),'spline')    ;
                [prevtotsumD, center , idx ] = UpdateCR(y, Xcov, distriArg, idx,k,m,linkArg, ftype ,xou,muv,beta,Inf,method);
            elseif iter==1 && isempty(ftype)
                [prevtotsumD, center , idx ] = UpdateCR(y, [], distriArg, idx,k,m,linkArg, ftype ,[],[],beta,Inf,method);   
            else
                [prevtotsumD, center , idx ] = UpdateCR(y, Xcov,distriArg,  idx,k,m,linkArg, ftype ,xou,muv,beta,prevtotsumD,method);
            end
            
        else
            if iter==1
                center = UpdateC(y, idx,k, [] ,beta,[],[], ftype ,threshold,linkArg, distriArg );
            else
                center = UpdateC(y, idx,k, Xcov ,beta,xou, muv, ftype ,threshold,linkArg, distriArg );
            end
        end
                
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %   updating f beta
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
        [xou,muv, mud, beta, ~] = Updatef(y, Xcov,  idx, beta,center ,frac, bw,kernel, nwe, npoly,nder,linkArg,distriArg,ftype );
    
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %  convergence
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
        if isempty(Xcov)
            CONVERGE = 1;    
        elseif    strcmp(ftype, 'non')
            pickXcov = Pick(Xcov,[],[],[],[]  );
            cov   = pickXcov* beta;
            covSample = linspace(min(cov )  ,max(cov )     ,100);
            
            f_new = interp1(xou, muv,  covSample ,'spline');
            if iter == 1
                f_old = 0;
            else
            precov = pickXcov* prebeta;
            precovSample  = linspace(min(precov )  ,max(precov )     ,100);  
            f_old = interp1(prexou, premuv,  precovSample ,'spline');
            end

            CONVERGE = norm(f_new -f_old,2)/(norm(f_old,2)) <   threshold ; 
        end
        
        prexou = xou;
        premuv = muv;
        prebeta = beta;
   
     
    end
    
    if CONVERGE == 0
        fprintf([ 'f does not converge' '\n'])
    end
end





