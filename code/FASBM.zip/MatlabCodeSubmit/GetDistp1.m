function D = GetDistp1(y, center,xou,muv,ftype,linkArg,beta,Xcov,method, distriArg)
% similar to getDistp function
% y is rectangular narrow * long
% Xcov is rectangular, same size as y

k = size(center,1);
m =  size(y,2) ;
m1 = size(y,1);
dataClass = superiorfloat(y);
[~,~,~,ilinkFun] = stattestlink(linkArg,dataClass);
D = zeros(m,k);

for i = 1:k
    if strcmp(ftype, 'non') &&  ~isempty(xou)  % f: nonparametric
        % deal with the m1 nodes
        dis = reshape(interp1(xou, muv,  reshape(Xcov*beta,[],1),'spline'),m1,m);
        mutemp =  ilinkFun(center(repmat(i,m1,1),:)+dis);
        % deal with the nodes (m-m1)
        Xcov1 = (Xcov(:,(m1+1:m)))' ;
        y1 = (y(:,(m1+1:m)))' ;
        dis1 = reshape(interp1(xou, muv,  reshape(Xcov1*beta,[],1),'spline'),m1,(m-m1));
        center1 = center(:, 1:m1 );
        mutemp1 =  ilinkFun(center1(repmat(i,(m-m1),1),:)+dis1);
    else  %f=0;
        % deal with the m1 nodes
        mutemp =  ilinkFun(center(repmat(i,m1,1),:));
        % deal with the nodes (m-m1)
        y1 = (y(:,(m1+1:m)))' ;
        center1 = center(:,1:m1);
        mutemp1 =  ilinkFun(center1(repmat(i,(m-m1),1),:));
    end
    
    switch method
        case 'LS'
            temp =  y-mutemp ;
            temp1 = y1 - mutemp1;
            D(1:m1,i) =  sum(temp.^2,2);
            D((m1+1:m),i) =  sum(temp1.^2,2);
            
            
        case 'loglikelihood'
            temp = y.*log(mutemp) + (1-y).* log(1-mutemp);
            temp1 = y1.*log(mutemp1) + (1-y1).* log(1-mutemp1);
            
            D(1:m1,i) = -sum(temp,2);
            D((m1+1:m),i) =  -sum(temp1,2);
            
            if strcmp(distriArg,'Bernoulli')
                temp = y.*log(mutemp) + (1-y).* log(1-mutemp);
                temp1 = y1.*log(mutemp1) + (1-y1).* log(1-mutemp1);
                D(1:m1,i) = -sum(temp,2);
                D((m1+1:m),i) =  -sum(temp1,2);
            elseif strcmp(distriArg,'Poisson')
                temp = y.*log(mutemp)-mutemp;
                temp1 = y1.*log(mutemp1)-mutemp1;
                D(1:m1,i) = -sum(temp,2);
                D((m1+1:m),i) =  -sum(temp1,2);
                
            end
                 
            
    end
    
    
end



end

