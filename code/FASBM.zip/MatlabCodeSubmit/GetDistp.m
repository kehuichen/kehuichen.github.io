function D = GetDistp(y, Center,xou,muv,ftype,linkArg,beta,Xcov,method,distriArg)

k = size(Center,1);
% reshape y to square matrix
if size(y,2) ==1
    m = sqrt(size(y,1));
    y = reshape(y,m,m);
else
    m =  size(y,2) ;
end
 
dataClass = superiorfloat(y);
[~,~,~,ilinkFun] = stattestlink(linkArg,dataClass);
D = zeros(m,k);
for i = 1:k
    if strcmp(ftype, 'non') &&  ~isempty(xou)  % f: nonparametric
        dis = reshape(interp1(xou, muv,  Xcov*beta,'spline'),size(y,1),size(y,2));
        
        mutemp =  ilinkFun(Center(repmat(i,m,1),:)+dis);
        
    else                                          % f = 0 
        mutemp =  ilinkFun(Center(repmat(i,m,1),:));
    end
    
    switch method
        case 'LS'
           temp =  y-mutemp ;
           temp(logical(eye(size(temp))))=0;
            D(:,i) = sum(temp.^2,2);   
                 
            
        case 'loglikelihood'
            if strcmp(distriArg,'Bernoulli')
            temp = y.*log(mutemp) + (1-y).* log(1-mutemp);
            elseif strcmp(distriArg,'Poisson')
            temp = y.*log(mutemp)-mutemp;
            end

            D(:,i) = -sum(temp,2);
            
    end
    
end





end

