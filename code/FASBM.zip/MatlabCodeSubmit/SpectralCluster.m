function [idx, Dsort] = SpectralCluster(CC, k, degree, L, reps)
S = diag(sum(CC)); 
CC = (S)^(-0.5)*CC*(S)^(-0.5);
[V, D] = eig(CC);
[Dsort, ind] = sort(abs(diag(D)),'descend');

VS = V(:,ind);
if degree == 1
   rV = VS(:, 1:L);
   for i = 1: size(rV,1);
       rV(i,:) = rV(i,:)/norm(VS(i,:));
   end
else
   rV = VS(:,1:L);
end

idx = kmeans(rV, k, 'Replicates', reps);

end

