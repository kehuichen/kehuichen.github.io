clc;clear;
% simulation for  k = 3,     two covaraites scenario

op = 100; 
M = [100 200 400];
Frac = [0.2 0.03 0.007];
bw = 0.9; 
 
 
a = 1.8;
b = -8;
rng('default')
rng(12345)

 
jj = 2;
m = M(jj);
n = m*m;
k =  3;
pos_store = zeros(op,m);
pos1_store = zeros(op,m);
work = zeros(op,n);
id_store = zeros(op,m);
idx_store = cell(op,1) ;
Beta_store = zeros(op,2);
P = repmat(1/k, k,1) ;  % proportion of each cluster
rho = 0.2;
prob = rho* [2.5  1  1  ; 1  1.5   1 ; 1 1 0.5  ];
CK_t = linkfun(prob, 2,0);
frac = Frac(jj);
 
 
   for  rn = 	1:100
          rng('shuffle')
        % random assignment
        r_perm = perms(1:k);  
        temp = mnrnd(ones( m,1),P);        
        applyToGivenRow = @(func, matrix) @(row) func(matrix(row, :));
        applyToRows = @(func, matrix) arrayfun(applyToGivenRow(func, matrix), 1:size(matrix,1))';
        temp = applyToRows(@find,temp);
        id_store(rn,:) = temp';
        idx_t = r_perm(:,temp)'; 
        pos  = rand(m,1);
        pos(temp==1) =   normrnd(-2,1,sum(temp==1),1) ; 
        pos(temp==2) =   normrnd( 2,1,sum(temp==2),1) ; 
        pos(temp==3) =   normrnd( 0,1,sum(temp==3),1) ;
        pos1 = rand(m,1);
        cov1 = reshape(dism(pos), n,1);
        cov2 = reshape(dism(pos1), n,1);
        cov1_1 = zscore(Pick(cov1,[],[],[],[]));  %standardize;
        COV1 = eye(m);
        COV1(tril(true(size(COV1)),-1)) = cov1_1;
        COV1 = reshape(tril(COV1)'+tril(COV1,1),m*m,1); 
        cov2_1 = zscore(Pick(cov2,[],[],[],[]));  %standardize;
        COV2 = eye(m);
        COV2(tril(true(size(COV2)),-1)) = cov2_1;
        COV2 = reshape(tril(COV2)'+tril(COV2,1),m*m,1); 
        disty = [COV1 COV2];
        disty1 = COV1;
        pos_store(rn,:) = pos;
        pos1_store(rn,:) = pos1;
        noise  =  1.8*sin(-4/3*(0.9798*COV1 + 0.2*COV2));
%         noise  =  1.8*sin(-4/3*(1*COV1  ));
        y_s = reshape(CK_t( idx_t(:,1), idx_t(:,1)),n,1)+noise ;   
        p_s =  linkfun(y_s,2,-1) ;
        y = reshape(binornd(1, p_s),m,m);
        y = triu(y)'+triu(y,1);    % symmetric
        y = reshape(y,n,1);
        work(rn,:) = y';
         
    [xou,muv,mud,idx,center,beta] = Quasifitv3(disty, y, m, k, 'logit', 'Bernoulli', 'non', 'loglikelihood', frac , bw,'gauss', 2, 2, 1);
          Beta_store(rn,:) = beta';
          idx_store{rn,1}= idx;
        miscluster_p(idx_t, idx )
  
        
   end
      
     

  
  
  
  
  











