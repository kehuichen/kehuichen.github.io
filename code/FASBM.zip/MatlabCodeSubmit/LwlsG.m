function [invalid,muv,mud]=LwlsG(bw,kernel,nwe,npoly,nder,xin,yin,win,xou,cin,linkArg,Iter,distriArg,~)

% It's coded for one-dimension local linear maximum likelihood estimation of f
 
% Input

%  bw                   specified bandwidth.
%  kernel               kernel
%  nwe                  degree of opt polynomial
%  npoly                degree of polynomial
%  nder                 order of derivative (npoly-nder=1 in our case)
%  xin(n,1)             vector of of x-coordinate (predictor)  n*1
%  yin(n,1)             vector of y-coordinates of input data   n*1
%  win(n,1)             vector of case weights of input data.
%  xou(N)               vector of output grid x-coordinate. Must be Sorted.
%  cin (n*1)            vector of constant values
%  linkArg:             link function,  acceptable values for  linkArg are 'identity', 'logit', 'log' 
%  Iter                 Iteration Step (iterate between f and beta) Identifier

% Output
%  invalid             Indicator for error message when bw specified is too small
%  muv(N)               vector of cross mean estimates   N*1
%  mud(N)               vector of first derivative estimates    N*1

if nargin ==13
    onestep = 0;
else onestep = 1;
end
actobs=find(win~= 0);
xin=xin(actobs);
yin=yin(actobs);
cin = cin(actobs);
win=win(actobs);
invalid=0;
aa=1;
muv=zeros( length(xou),1);
mud = zeros( length(xou),1);
gap=[];
maxit_f = 100;
BW = ones(1,length(xou))*bw;   %global bandwidths
threshold = 1e-6;
dataClass = superiorfloat(xin,yin);
[~,~,~,ilinkFun] = stattestlink(linkArg,dataClass);


% LWLS with different weight functions
for i=1:length(xou)
    if strcmp(kernel, 'gauss') == 0 && strcmp(kernel, 'gausvar') == 0
        list1=find(xin<= xou(i)+aa*BW(i));
        list2=find(xin>= xou(i)-aa*BW(i));
        list=intersect(list1,list2);
    else
        list = 1:length(xin);
    end
    
    lx=xin(list);
    ly=yin(list);
    lw=win(list);
    lc=cin(list);
    
    if length(unique(lx)) >= (npoly+1)
        % Specify weight matrix
        llx=(lx-xou(i))/BW(i);
        if strcmp(kernel,'epan') == 1
            w=lw.*(1-llx.^2)*0.75;
        elseif strcmp(kernel, 'optp') == 1
            w=lw.*(1-llx.^2).^(nwe-1);
        elseif strcmp(kernel,'gauss') == 1
            w=lw.*exp(-0.5*(llx.^2))./sqrt(2*pi);
        elseif strcmp(kernel,'gausvar') == 1
            w=lw.*exp(-0.5*(llx.^2))./sqrt(2*pi).*(1.25-0.25*llx.^2);
        elseif strcmp(kernel, 'quar') == 1
            w = lw.*((1-llx.^2).^2)*(15/16);
        else
            fprintf(1,'Invalid kernel, Epanechnikov kernel is used!\n');
            w=lw.*(1-llx.^2)*0.75;
        end
        temp=(1:length(w))';
        W=sparse(temp,temp,w');
        % Define design matrix
        dx=ones(length(lx),npoly+1);
        for j=1:npoly
            dx(:,j+1)=(xou(i)-lx)'.^j;
        end
        
        switch linkArg
            
            case 'identity'
                B =pinv(dx'*W*dx)*dx'*W*(ly-lc);
                converge =1;
                
            case {'logit','log'}
                Bini = pinv(dx'*W*dx)*dx'*W*(ly-lc);
                Xreg = dx;
                Y = ly;
                B_old = Bini;
                if onestep ~=1
                    iter = 0;
                    converge = 0;
                else iter = maxit_f-1;
                    converge =1;
                end
                while iter < maxit_f
                    iter = iter +1;
                    eta2 = lc + Xreg * B_old;
                    mu = ilinkFun(eta2)  ;
                    addW =  W;
                    der =  Xreg';
                    B = Betaupd(B_old, Y,der, mu,addW,linkArg, distriArg) ;
                    if norm(B-B_old,1)/(norm(B_old,1)) < threshold
                        converge = 1 ;
                        break;
                    end
                    B_old = B;
                end
        end
        
        % Find estimate  and derivative
        if ~converge
            fprintf(['warning: lwlsG xou ' num2str(i) 'in iter_fbeta' num2str(Iter)  '\n']);
        end
        muv(i)=B(1)*factorial(0)*((-1)^0);
        mud(i)=B(nder+1)*factorial(nder)*((-1)^nder);
        gap(i)=0;
    else
        gap(i)=1;
        invalid=1;
    end
end
indx=find(gap==0);
if length(indx)>=0.9*length(xou)&&length(indx)<length(xou)
    xou1=xou(indx);
    mu1=muv(indx);
    mud1 = mud(indx);
    [xou2,id1]=unique(xou1);
    mu2=mu1(id1);
    mud2 = mud1(id1);
    muv=interp1(xou2,mu2,xou,'spline');
    mud = interp1(xou2, mud2,xou,'spline');
elseif  length(indx)<0.9*length(xou)
    muv='too many gaps, please increase bandwidth';
    invalid = 1;
end

end




