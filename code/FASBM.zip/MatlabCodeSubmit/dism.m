function [disty] =  dism(X)
% Input
%     X: n*p matrix n: number of nodes   p: number of coordinateds
% Output  
%     disty: (n*n) vector pairwise distance between coordinates
m = size(X,1);
dis = (pdist(X))' ;
dis_r = mat2cell(dis, m-1:-1:1, 1);
disty = zeros(m,m);
for i = 1: (m-1)
    disty(i,(i+1):m) =  dis_r{i,1} ;
end
disty = disty + triu(disty, 1)';
end
