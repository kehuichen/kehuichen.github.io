function [ center ] = UpdateC(y, idx,k, Xcov ,beta,xou,muv, ftype ,threshold,linkArg, distriArg)
% It's coded for updating C

dataClass = superiorfloat(y);
[~,~,~,ilinkFun] = stattestlink(linkArg,dataClass);
center_old = zeros(k,k);
center = center_old;
maxit_fc = 100;

for i = 1: k
    for j= i:k
        converge_c = 0;
        Y_t = Pick(y,[],idx,i,j );
        n1 = size(Y_t,1);
        if n1 ==1
            fprintf(['single node cluster ' num2str(k) '\n']);
        end
     
        if  ~isempty(Xcov)
            Xcov_t = Pick(Xcov,[],idx,i,j);
            xin_t = Xcov_t *beta;
        end
        
        % initialization
        if  isempty(ftype)
            center_old(i,j) = sum(Y_t)/n1;
        elseif strcmp(ftype, 'non') 
            center_old(i,j) = sum(Y_t-interp1(xou, muv, xin_t,'spline'))/n1;
        end
        
        switch  linkArg
            case 'identity'
                center(i,j) = center_old(i,j) ;
            case {'logit' ,'log'}
                iter_fc = 0;
                % updating
                while  converge_c == 0  && iter_fc < maxit_fc
                    iter_fc = iter_fc + 1;
                    if ~isempty(Xcov) && strcmp(ftype, 'non')
                        eta2 = repmat(center_old(i,j),n1,1) +  interp1(xou, muv, xin_t,'spline');
                    elseif   isempty(ftype)
                        eta2 = repmat(center_old(i,j),n1,1);
                    end
                    mu = ilinkFun(eta2);
                    der =  ones(1,n1);
                    center(i,j)= Betaupd(center_old(i,j), Y_t,der, mu,[],linkArg,distriArg) ;
                    
                    converge_c = norm((center_old(i,j)-center(i,j)),1)/ (norm(center_old(i,j),1)) < threshold;
                    
                    center_old(i,j) = center(i,j) ;
                end
                
                if ~converge_c
                    fprintf(['iter_c does not converge  ' num2str(i) ,num2str(j),'\n']);
                end
        end
    end
end
center =  triu(center)'+triu(center,1);
end
