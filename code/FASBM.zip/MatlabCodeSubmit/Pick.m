function [X_pick] = Pick( X, Xcov, idx, s1,s2,  ~ )
%  It's coded for extracting  part of the data  (always excluding  self-loop)
%  Input?
%         X          (m*m)-by-s matrix by default, or a general rectangular matrix w * l if  nargin = 7
%         Xcov       (m*m)-by-1 feature matrix  
%         idx         partition results in m-by-1   matrix  or []. If [], then output upper triangular of X
%         s1 s2       if [], then output upper triangular of X,
%                     else output the corresponding block with s1 s2 labels
%                     excluding self-loop
 


%  Output: 
%         X_pick      Selected elements in X with ncol=s 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%     update on April 27, 2016
 
    

if nargin == 5;
    spec = 'sym';
else spec =  'rec';
end

 
switch spec
    case 'sym'
        kk = sqrt(size(X,1));
     
        if ~isempty(Xcov)
            X_pick = [];
            Xcov = reshape(Xcov,kk,kk) ;
            idxx = true(size(Xcov));
            idxx(tril(idxx)) = false;
            Xcov1 = Xcov(idxx);
   
            
            for l = 1: size(X,2)          
                Xtrans  =  reshape(X(:,l),kk,kk) ;
                if isempty(idx)                        % pick upper triangle if idx=[]
                    idxx = true(size(Xtrans));
                    idxx(tril(idxx)) = false;
            
                elseif s1~=s2
                    idxx = false(size(Xtrans));         % else pick elements by two differnent memberships (no self-loop issue)
                    idxx(idx==s1, idx==s2) = true;
                    idxx(idx==s2,idx==s1) =  true;
                  
                else                                    % pick elements by two same memberships
                    idxx = false(size(Xtrans));
                    idxx(idx==s1, idx==s2) = true;
                    idxx(tril(idxx)) = false;
                   
                end
                
                X_picktemp = Xtrans(idxx);
                X_pick = [X_pick reshape(X_picktemp,size(X_picktemp,1)*size(X_picktemp,2),1)];
            end
            
        else
            X_pick = [];    % when Xcov is empty
            for l = 1: size(X,2)
                
                Xtrans  =  reshape(X(:,l),kk,kk) ;
                if isempty(idx)                        % pick upper triangle if idx=[]
                    idxx = true(size(Xtrans));
                    idxx(tril(idxx)) = false;
                    
                elseif s1~=s2
                    idxx = false(size(Xtrans));         %else pick elements by two differnent memberships (no self-loop issue)
                    idxx(idx==s1, idx==s2) = true;
                    idxx(idx==s2,idx==s1) =  true;
                else                                    % pick elements by two same memberships
                    idxx = false(size(Xtrans));
                    idxx(idx==s1, idx==s2) = true;
                    idxx(tril(idxx)) = false;
                    
                end
                
                X_picktemp = Xtrans(idxx);
                X_pick = [X_pick reshape(X_picktemp,[],1)];
            end
            
        end
        
    case 'rec'
        % make the X rectangle,  narrow * long
        % long = number of nodes = size(idx)
        % make Xcov rectangle, narrow * long
        % return vector
        %  Input Xcov    nrow= (m*m), ncol=1 (only needed when truncp is not []
        
        if isempty(truncp)
            truncp_u = 1;
            truncp_l = 0;
        else
            truncp_l = truncp(1);
            truncp_u = truncp(2);
         end
        
        if size(X,1) > size(X,2)
            X = X';
        end
        
        w =  size(X,1)  ;
        
      %  divided by difference situations for Xcov  
        if ~isempty(Xcov)
            Xcov1 = reshape(triu(Xcov,1),[],1);
            upper = quantile(Xcov1,truncp_u);
            lower = quantile(Xcov1,truncp_l);
            Xtrans  = X ;
            if isempty(idx)                        % pick upper triangle if idx=[]
                idxx = true(size(Xtrans)) ;   % pick upper triangle if idx=[]
                idxx(tril(idxx)) = false;
                idxx(Xcov > upper  | Xcov < lower) = false;
            else 
                
                idxx = false(size(Xtrans));         %else pick elements by two differnent memberships (no self-loop issue)
                idxx(idx(1:w)==s1, idx==s2) = true;
                idxx(idx(1:w)==s2, idx==s1) = true;
                idxx(tril(idxx)) = false;
                idxx(Xcov > upper  | Xcov < lower) = false;     
            end
            
            X_picktemp = Xtrans(idxx);
            X_pick = reshape(X_picktemp,[] ,1) ;
            
        else

            Xtrans  =  X;  
            if isempty(idx)
                idxx = true(size(Xtrans)) ;   % pick upper triangle if idx=[]
                idxx(tril(idxx)) = false;
                
            else
                idxx = false(size(Xtrans));         %else pick elements by two differnent memberships (no self-loop issue)
                idxx(idx(1:w)==s1, idx==s2) = true;
                idxx(idx(1:w)==s2, idx==s1) = true;
                idxx(tril(idxx)) = false;
            end
            
            X_picktemp = Xtrans(idxx);
            X_pick = reshape(X_picktemp,[] ,1) ;
            
        end
end

end

