function[prevtotsumD, center_new, idx_new] = UpdateCR(y, Xcov,distriArg, idx,k,m,linkArg, ftype ,xou,muv,beta,prevtotsumD,method)
% It's coded for updating C and then updating R until R converges
%   Input: 
 
%  y:           network in (m*m)-by-1 matrix 
%  Xcov:        feature matrix in (m*m)-by-s matrix  
%  distriArg:   Distribution,   acceptable values for  distriArg are 'Normal', 'Bernoulli', 'Poisson'.
%  idx:         Current community labels  
%  k:           number of communities
%  m:           number of nodes
%  linkArg:     link function,  acceptable values for  linkArg are 'identity', 'logit', 'log' 
%  ftype:       f = 0 or f is an unknown smooth function.  Acceptable values are []  or 'non'. 
% xou muv:      Current estimate of f
%  beta:
%  prevtotsumD: Current negative log-likelihood or sum of squared residuals depending on which method is used
%  method:      method used for updating labels,  acceptable values are 'LS'  or 'loglikelihood'.  'LS' is least-squares method minimizing
%               the sum of squared residuals. 'loglikelihood' will minimize negative of the sum of loglikelihood

converge_cr = 0;
threshold = 1e-4;
maxit_cr = 100;
iter_cr = 0;

while converge_cr == 0 && iter_cr < maxit_cr
    
    iter_cr= iter_cr +1;

    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %   updating C
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%
    center = UpdateC(y, idx,k, Xcov ,beta,xou,muv, ftype ,threshold,linkArg, distriArg );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %   updating R
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%
    if size(y,2) == 1
        D  = GetDistp(y, center(:,idx),xou,muv,ftype,linkArg,beta,Xcov,method, distriArg);
    else
        D  = GetDistp1(y, center(:,idx),xou,muv,ftype,linkArg,beta,Xcov,method, distriArg);   % deal with rectangular y
    end
    totsumD = sum(D((idx-1)*m + (1:m)'));
    
    % Test for a cycle: if objective is not decreased, stop
    if prevtotsumD <= totsumD
        totsumD = prevtotsumD;
        converge_cr = 1;
        break;
    end
    
    % Determine closest cluster for each point and reassign points to clusters
    previdx = idx;
    prevtotsumD = totsumD;
    [d, nidx] = min(D, [], 2);
    % Determine which points moved
    moved = find(nidx ~= previdx);
    if ~isempty(moved)
        % Resolve ties in favor of not moving
        moved = moved(D((previdx(moved)-1)*m + moved) > d(moved));
    end
    if isempty(moved)
        converge_cr = 1;
    end
    
    idx(moved) = nidx(moved);
    
end
idx_new = idx;
center_new = center;
prevtotsumD = totsumD;
if converge_cr == 0
    fprintf([ 'update CR does not converge' '\n'])
end

end
