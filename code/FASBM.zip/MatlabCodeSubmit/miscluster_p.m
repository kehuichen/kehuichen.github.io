function [misp,A] = miscluster_p(R_t, i_t)
%R_t: true labels, with dimension n by factorial(k)
%i_t: labels obtained, with dimension n by 1
%Output: percentages of misassigned nodes 
A =[];
k = length(unique(R_t));   % number of labels
i_td = dummyvar(i_t);
for g = 1:factorial(k)
    r_td = dummyvar(R_t(:,g));
    temp = i_td-r_td;
    A = [A;sum(temp(:) ~=0)];
end
misp = min(A,[],1)/(2*length(i_t));

end

