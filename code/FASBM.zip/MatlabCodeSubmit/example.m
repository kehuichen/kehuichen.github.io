m = 100;
n = m*m;
k = 2;
rng(12345)
prob = 0.2* [2.5  1   ; 1   1  ];
CK_t = log(prob./(1-prob));
disty = reshape(dism(rand(m,1)), n,1);
r_perm = perms(1:k);
P = repmat(1/k, k,1) ;
temp = mnrnd(ones( m,1),P);
applyToGivenRow = @(func, matrix) @(row) func(matrix(row, :));
applyToRows = @(func, matrix) arrayfun(applyToGivenRow(func, matrix), 1:size(matrix,1))';
temp = applyToRows(@find,temp);
idx_t = r_perm(:,temp')'; 


y_s = reshape(CK_t(temp', temp'),n,1)+  1.4*sin(-8*disty);
p_s =  exp(y_s)./(1+exp(y_s)) ;
y = reshape(binornd(1, p_s),m,m);
y = triu(y)'+triu(y,1);    % symmetric
y = reshape(y,n,1);
[xou,muv,mud,idx,center,beta] = Quasifitv3(disty, y, m, k, 'logit', 'Bernoulli', 'non', 'loglikelihood', 0.2 , 0.1,'gauss', 2, 2, 1);
xx = linspace(0,max(disty),100);
yy =  1.4*sin(-8*xx) ;
miscluster_p(idx_t, idx)


plot(xx,yy,'b')
hold on
plot(xou,muv,'g')

 