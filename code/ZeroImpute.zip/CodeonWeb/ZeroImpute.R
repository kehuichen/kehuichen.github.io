#This is an implementation of the Zero Imputation method in recommender system.

#Reference Paper: J. Lu and K Chen ``A Zero-imputation approach in recommendation systems with data missing heterogeneously", in Statistica Sinica.


#ZeroImpute.R script includes two functions: zeroimpute and zeroimpute_coldstart. The rating scale is 1:K.

library(RSpectra)
library(CVXR)
library(ranger)
library(data.table)

zeroImpute<-function(data,p=NULL,K=5,p_candi=c(10,50,150),u_id=NULL,v_id=NULL){
	#input:
	#data: observed rating matrix, in tuple form (user,item,score)
	#p: latent dimension, if not prodived, it will tune on the grid of p_candi
	#u_id: user_id on test set
	#v_id: item_id on test set
	#output: a predicted vector
	
  Tuning<-function(data_train,p_candi,K=5){
    
    temp_udim<-dim(data_train)[1]
    temp_vdim<-dim(data_train)[2]
    
    u_index<-1:temp_udim
    v_index<-1:temp_vdim
    
    A<-data_train
    
    whole_index<-1:length(A@x)
    
    train_index<-sample(whole_index,as.integer(length(whole_index)*0.9),replace = F)
    test_index<-setdiff(whole_index,train_index)
    temp_truth<-(A@x)[test_index]
    temp_train<-A
    
    idx1<-temp_train@i+1 
    idx2<-findInterval(seq(temp_train@x)-1,temp_train@p[-1])+1
    
    idx1_train<-idx1[train_index]
    idx2_train<-idx2[train_index]
    
    idx1_test<-idx1[test_index]
    idx2_test<-idx2[test_index]
    
    
    temp_train<-sparseMatrix(i =idx1_train, j = idx2_train, x=A@x[train_index],dims=c(temp_udim,temp_vdim))
    
    rate_candi<-2:K
    temp_ans<-rep(0,length(p_candi))
    for(j in 1:length(p_candi)){
      p<-p_candi[j]
      n.cores=8
      cl<-makeCluster(n.cores)
      registerDoParallel(cl)  # use multicore, set to the number of our cores
      zi<-foreach (rate=1:(2*length(rate_candi)),.combine=cbind,.packages=c('RSpectra'))%dopar%{
        if(rate <=length(rate_candi)){
          A_train_rate<-temp_train
          
          A_train_rate@x<- as.numeric( (A_train_rate@x>=rate_candi[rate]  ) )
          
          A_train_rate<-as(A_train_rate, "sparseMatrix")
          
          temp<-svds(A_train_rate,k=p)
          
          t2<-t(t(temp$u[idx1_test,]) * pmax(0,(temp$d-temp$d[length(temp$d)])))
          t2<-t2 * (temp$v[idx2_test,])
          t2<-rowSums(t2)
          t2[t2< 0]<- 1e-6
          t2
        }else{
          A_train_rate<-temp_train
          
          A_train_rate@x<- as.numeric( (A_train_rate@x<rate_candi[rate-length(rate_candi)]  ) )
          
          A_train_rate<-as(A_train_rate, "sparseMatrix")
          
          temp<-svds(A_train_rate,k=p)
          t2<-t(t(temp$u[idx1_test,]) * pmax(0,(temp$d-temp$d[length(temp$d)])))
          t2<-t2 * (temp$v[idx2_test,])
          t2<-rowSums(t2)
          t2[t2< 0]<- 1e-6
          t2
        }
      }
      stopCluster(cl)
      
      
      pred_score=rep(1,length(idx1_test))
      
      for (i in  rate_candi){
        pred_score=pred_score+zi[,i-1]/pmax(1e-6,zi[,i-1]+zi[,i+K-2])
      }
      
      temp_ans[j]<-sqrt(  mean( (pred_score-temp_truth)^2  )  )
    }
    return(p_candi[which.min(temp_ans)])
  }
  if (length(u_id)!=length(v_id)){
    print ('u_id length differs from v_id!')
    return (0)
  }
  
  if (is.null(p)){
    print('Tuning dimension p')
    p=Tuning(data,p_candi=p_candi)
    print(paste ('p is selected as ', p, sep = "", collapse = NULL))
  }
  n.cores=2*(K-1)
  rate_candi<-2:K

  cl<-makeCluster(n.cores)
  registerDoParallel(cl)  # use multicore, set to the number of our cores
  zi<-foreach (rate=1:(2*length(rate_candi)),.combine=cbind,.packages=c('RSpectra'))%dopar%{
    if(rate <=length(rate_candi)){
      A_train_rate<-data
      
      A_train_rate@x<- as.numeric( (A_train_rate@x>=rate_candi[rate]  ) )

      A_train_rate<-as(A_train_rate, "sparseMatrix")

      temp<-svds(A_train_rate,k=p)
      
      t2<-t(t(temp$u[u_id,]) * pmax(0,(temp$d-temp$d[length(temp$d)])))
      t2<-t2 * (temp$v[v_id,])
      t2<-rowSums(t2)
      t2[t2< 0]<- 1e-6
      t2
    }else{
      A_train_rate<-data
      
      A_train_rate@x<- as.numeric( (A_train_rate@x<rate_candi[rate-length(rate_candi)]  ) )
      
      A_train_rate<-as(A_train_rate, "sparseMatrix")
      
      temp<-svds(A_train_rate,k=p)
      t2<-t(t(temp$u[u_id,]) * pmax(0,(temp$d-temp$d[length(temp$d)])))
      t2<-t2 * (temp$v[v_id,])
      t2<-rowSums(t2)
      t2[t2< 0]<- 1e-6
      t2
    }
  }
  stopCluster(cl)
  ans<-rep(1,length(u_id))
  for (i in 2:K){
  ans<-ans+zi[,i-1]/pmax(1e-6,zi[,i-1]+zi[,i+3])
  }
  return (ans)
}

zeroImpute_coldstart<-function(data,p=NULL,K=5,p_candi=c(10,50,150),u_fea,v_fea,u_new_fea,v_new_fea){
	# Input:
	#data: observed rating matrix
	#u_fea: old user covariates
	#v_fea: old item covariates
	#u_new_fea: new user covariates
	#v_new_fea: new item covariates
	# Output: 
	# item-cold, user-cold, and both cold predictions on all entries.
	
  Tuning<-function(data_train,p_candi,K=5){
    
    temp_udim<-dim(data_train)[1]
    temp_vdim<-dim(data_train)[2]
    
    u_index<-1:temp_udim
    v_index<-1:temp_vdim
    
    A<-data_train
    
    whole_index<-1:length(A@x)
    
    train_index<-sample(whole_index,as.integer(length(whole_index)*0.9),replace = F)
    test_index<-setdiff(whole_index,train_index)
    temp_truth<-(A@x)[test_index]
    temp_train<-A
    
    idx1<-temp_train@i+1 
    idx2<-findInterval(seq(temp_train@x)-1,temp_train@p[-1])+1
    
    idx1_train<-idx1[train_index]
    idx2_train<-idx2[train_index]
    
    idx1_test<-idx1[test_index]
    idx2_test<-idx2[test_index]
    
    
    temp_train<-sparseMatrix(i =idx1_train, j = idx2_train, x=A@x[train_index],dims=c(temp_udim,temp_vdim))
    
    rate_candi<-2:K
    temp_ans<-rep(0,length(p_candi))
    for(j in 1:length(p_candi)){
      p<-p_candi[j]
      n.cores=8
      cl<-makeCluster(n.cores)
      registerDoParallel(cl)  # use multicore, set to the number of our cores
      zi<-foreach (rate=1:(2*length(rate_candi)),.combine=cbind,.packages=c('RSpectra'))%dopar%{
        if(rate <=length(rate_candi)){
          A_train_rate<-temp_train
          
          A_train_rate@x<- as.numeric( (A_train_rate@x>=rate_candi[rate]  ) )
          
          A_train_rate<-as(A_train_rate, "sparseMatrix")
          
          temp<-svds(A_train_rate,k=p)
          
          t2<-t(t(temp$u[idx1_test,]) * pmax(0,(temp$d-temp$d[length(temp$d)])))
          t2<-t2 * (temp$v[idx2_test,])
          t2<-rowSums(t2)
          t2[t2< 0]<- 1e-6
          t2
        }else{
          A_train_rate<-temp_train
          
          A_train_rate@x<- as.numeric( (A_train_rate@x<rate_candi[rate-length(rate_candi)]  ) )
          
          A_train_rate<-as(A_train_rate, "sparseMatrix")
          
          temp<-svds(A_train_rate,k=p)
          t2<-t(t(temp$u[idx1_test,]) * pmax(0,(temp$d-temp$d[length(temp$d)])))
          t2<-t2 * (temp$v[idx2_test,])
          t2<-rowSums(t2)
          t2[t2< 0]<- 1e-6
          t2
        }
      }
      stopCluster(cl)
      
      
      pred_score=rep(1,length(idx1_test))
      
      for (i in  rate_candi){
        pred_score=pred_score+zi[,i-1]/pmax(1e-6,zi[,i-1]+zi[,i+K-2])
      }
      
      temp_ans[j]<-sqrt(  mean( (pred_score-temp_truth)^2  )  )
    }
    return(p_candi[which.min(temp_ans)])
  }
  if (is.null(p)){
    print('Tuning dimension p')
    p=Tuning(data,p_candi=p_candi)
    print(paste ('p is selected as ', p, sep = "", collapse = NULL))
  }
  

  n.cores=2*(K-1)
  rate_candi<-2:K
  cl<-makeCluster(n.cores)
  registerDoParallel(cl)  # use multicore, set to the number of our cores
  res<-foreach (rate=1:(2*length(rate_candi)),.packages='RSpectra')%dopar%{
    if(rate <=length(rate_candi)){ 
      A_train_rate<-data
      
      A_train_rate@x<- as.numeric( (A_train_rate@x>=rate_candi[rate]  ) )
      
      A_train_fill<-A_train_rate
      A_train_fill<-as(A_train_fill, "sparseMatrix") 
      
      temp<-svds(A_train_fill,k=p)
      t2<-temp$u%*%diag(pmax(0,(temp$d-temp$d[p])))%*%t(temp$v)
      t2[t2< 1e-6]<- 1e-6
      t2[t2> 1-1e-6]<- 1-1e-6
      t2
    }else{
      A_train_rate<-data
      
      A_train_rate@x<- as.numeric( (A_train_rate@x<rate_candi[rate-length(rate_candi)]  ) )
      
      A_train_fill<-A_train_rate
      
      A_train_fill<-as(A_train_fill, "sparseMatrix") 
      
      temp<-svds(A_train_fill,k=p)
      t2<-temp$u%*%diag(pmax(0,(temp$d-temp$d[p])))%*%t(temp$v)
      t2[t2< 1e-6]<- 1e-6
      t2[t2> 1-1e-6]<- 1-1e-6
      t2
    }
  }
  stopCluster(cl)

  cl<-makeCluster(n.cores)
  registerDoParallel(cl)  # use multicore, set to the number of our cores
  foreach(rate=1:(2*length(rate_candi)),.combine=cbind,.packages=c('CVXR','ranger','RSpectra','data.table'))%dopar%{
    if(rate<=4){
      A_impute_fill<-res[[rate]]
      A_impute_fill<-as.matrix(A_impute_fill)
      temp_svd_fill<-svds(A_impute_fill,k=p)
      u_latent<-temp_svd_fill$u[,1:p]%*%diag(sqrt(temp_svd_fill$d[1:p]) )
      v_latent<-temp_svd_fill$v[,1:p]%*%diag(sqrt(temp_svd_fill$d[1:p]) )
      
      u_hat_rf=matrix(0,ncol=p,nrow=dim(u_new_fea)[1])

      for(j in 1:p){
        A.reg=cbind(u_latent[,j], u_fea) 
        A.reg=as.data.frame(A.reg)
        colnames( A.reg)[1]<-"response"
        assign (  paste("u_rf",j,sep="") ,ranger(response ~ ., data = A.reg, write.forest = TRUE) )
      }
      
      for(j in 1:p){
        u_hat_rf[,j]=stats::predict(  get(paste("u_rf",j,sep="") ),data=u_new_fea   )$predictions
      }
      v_hat_rf=matrix(0,ncol=p,nrow=dim(v_new_fea)[1])
      for(j in 1:p){
        A.reg=cbind(v_latent[,j],v_fea)
        A.reg=as.data.frame(A.reg)
        colnames( A.reg)[1]<-"response"
        assign (  paste("v_rf",j,sep="") ,ranger(response ~ ., data = A.reg, write.forest = TRUE) )
      }
      
      for(j in 1:p){
        v_hat_rf[,j]=stats::predict(  get(paste("v_rf",j,sep="") ),data=v_new_fea   )$predictions
      }
      x_weight<-matrix(0,ncol=dim(A_impute_fill)[1],nrow=dim(u_hat_rf)[1])
      design<-v_hat_rf%*%t(u_latent)
      out<-v_hat_rf%*%t(u_hat_rf)
      for(i in 1:dim(u_hat_rf)[1] ) {

        resp<-out[,i]
        
        w=Variable(dim(u_latent)[1])
        constraints <-  list(w  >= 0,sum(w)==1)
        objective <-Minimize(  cvxr_norm(design%*%w-resp, "fro")       )
        prob<- Problem(objective,constraints)
        solution <- solve(prob,solver = "SCS")
        x_weight[i,]<-solution$getValue(w)
      }
      y_weight<-matrix(0,ncol=dim(A_impute_fill)[2],nrow=dim(v_hat_rf)[1])
      design<-u_hat_rf%*%t(v_latent)
      out<-u_hat_rf%*%t(v_hat_rf)
      for(i in 1:dim(v_hat_rf)[1] ) {
        resp<-out[,i]
        
        w=Variable(dim(v_latent)[1])
        constraints <-  list(w  >= 0,sum(w)==1)
        objective <-Minimize(  cvxr_norm(design%*%w-resp, "fro")       )
        prob<- Problem(objective,constraints)
        solution <- solve(prob,solver = "SCS")
        y_weight[i,]<-solution$getValue(w)
      }
      fwrite(list(pmax(1e-6, as.vector(A_impute_fill%*% t(y_weight)) )),paste("rate2",rate+1,".txt",sep="") )
      fwrite(list(pmax(1e-6, as.vector(x_weight %*%A_impute_fill) )),paste("rate3",rate+1,".txt",sep="") )
      fwrite(list(pmax(1e-6, as.vector(x_weight %*%A_impute_fill%*% t(y_weight)) )),paste("rate4",rate+1,".txt",sep="") )
    }else{
      A_impute_fill<-res[[rate]]
      A_impute_fill<-as.matrix(A_impute_fill)
      temp_svd_fill<-svds(A_impute_fill,k=p)
      u_latent<-temp_svd_fill$u[,1:p]%*%diag(sqrt(temp_svd_fill$d[1:p]) )
      v_latent<-temp_svd_fill$v[,1:p]%*%diag(sqrt(temp_svd_fill$d[1:p]) )
      
      u_hat_rf=matrix(0,ncol=p,nrow=dim(u_new_fea)[1])
      
      for(j in 1:p){
        A.reg=cbind(u_latent[,j], u_fea) 
        A.reg=as.data.frame(A.reg)
        colnames( A.reg)[1]<-"response"
        assign (  paste("u_rf",j,sep="") ,ranger(response ~ ., data = A.reg, write.forest = TRUE) )
      }
      
      for(j in 1:p){
        u_hat_rf[,j]=stats::predict(  get(paste("u_rf",j,sep="") ),data=u_new_fea   )$predictions
      }
      v_hat_rf=matrix(0,ncol=p,nrow=dim(v_new_fea)[1])
      for(j in 1:p){
        A.reg=cbind(v_latent[,j],v_fea)
        A.reg=as.data.frame(A.reg)
        colnames( A.reg)[1]<-"response"
        assign (  paste("v_rf",j,sep="") ,ranger(response ~ ., data = A.reg, write.forest = TRUE) )
      }
      
      for(j in 1:p){
        v_hat_rf[,j]=stats::predict(  get(paste("v_rf",j,sep="") ),data=v_new_fea   )$predictions
      }
      x_weight<-matrix(0,ncol=dim(A_impute_fill)[1],nrow=dim(u_hat_rf)[1])
      design<-v_hat_rf%*%t(u_latent)
      out<-v_hat_rf%*%t(u_hat_rf)
      for(i in 1:dim(u_hat_rf)[1] ) {
        
        resp<-out[,i]
        
        w=Variable(dim(u_latent)[1])
        constraints <-  list(w  >= 0,sum(w)==1)
        objective <-Minimize(  cvxr_norm(design%*%w-resp, "fro")       )
        prob<- Problem(objective,constraints)
        solution <- solve(prob,solver = "SCS")
        x_weight[i,]<-solution$getValue(w)
      }
      y_weight<-matrix(0,ncol=dim(A_impute_fill)[2],nrow=dim(v_hat_rf)[1])
      design<-u_hat_rf%*%t(v_latent)
      out<-u_hat_rf%*%t(v_hat_rf)
      for(i in 1:dim(v_hat_rf)[1] ) {
        resp<-out[,i]
        
        w=Variable(dim(v_latent)[1])
        constraints <-  list(w  >= 0,sum(w)==1)
        objective <-Minimize(  cvxr_norm(design%*%w-resp, "fro")       )
        prob<- Problem(objective,constraints)
        solution <- solve(prob,solver = "SCS")
        y_weight[i,]<-solution$getValue(w)
      }
      fwrite(list(pmax(1e-6, as.vector(A_impute_fill%*% t(y_weight)) )),paste("r_rate2",rate-3,".txt",sep="") )
      fwrite(list(pmax(1e-6, as.vector(x_weight %*%A_impute_fill) )),paste("r_rate3",rate-3,".txt",sep="") )
      fwrite(list(pmax(1e-6, as.vector(x_weight %*%A_impute_fill%*% t(y_weight)) )),paste("r_rate4",rate-3,".txt",sep="") ) 
      1
    }
  }
  stopCluster(cl)
  
  rating_p2<-NULL
  rating_p2_r<-NULL
  for (rate in 2:5){
    rating_p2[[rate]]<-unlist(fread(paste("rate2",rate,".txt",sep="")))
  }
  for (rate in 2:5){
    rating_p2_r[[rate]]<-unlist(fread(paste("r_rate2",rate,".txt",sep="")))
  }
  r5_scale2<-rating_p2[[5]]/(rating_p2[[5]]+rating_p2_r[[5]])
  r4_scale2<-rating_p2[[4]]/(rating_p2[[4]]+rating_p2_r[[4]])
  r3_scale2<-rating_p2[[3]]/(rating_p2[[3]]+rating_p2_r[[3]])
  r2_scale2<-rating_p2[[2]]/(rating_p2[[2]]+rating_p2_r[[2]])
  
  pred_score2<-as.vector(1+r2_scale2+ r3_scale2+ r4_scale2+ r5_scale2)
  
  rating_p3<-NULL
  rating_p3_r<-NULL
  for (rate in 2:5){
    rating_p3[[rate]]<-unlist(fread(paste("rate3",rate,".txt",sep="")))
  }
  for (rate in 2:5){
    rating_p3_r[[rate]]<-unlist(fread(paste("r_rate3",rate,".txt",sep="")))
  }
  r5_scale3<-rating_p3[[5]]/(rating_p3[[5]]+rating_p3_r[[5]])
  r4_scale3<-rating_p3[[4]]/(rating_p3[[4]]+rating_p3_r[[4]])
  r3_scale3<-rating_p3[[3]]/(rating_p3[[3]]+rating_p3_r[[3]])
  r2_scale3<-rating_p3[[2]]/(rating_p3[[2]]+rating_p3_r[[2]])
  pred_score3<-1+r2_scale3+ r3_scale3+ r4_scale3+ r5_scale3
  
  rating_p4<-NULL
  rating_p4_r<-NULL
  for (rate in 2:5){
    rating_p4[[rate]]<-unlist(fread(paste("rate4",rate,".txt",sep="")))
  }
  for (rate in 2:5){
    rating_p4_r[[rate]]<-unlist(fread(paste("r_rate4",rate,".txt",sep="")))
  }
  r5_scale4<-rating_p4[[5]]/(rating_p4[[5]]+rating_p4_r[[5]])
  r4_scale4<-rating_p4[[4]]/(rating_p4[[4]]+rating_p4_r[[4]])
  r3_scale4<-rating_p4[[3]]/(rating_p4[[3]]+rating_p4_r[[3]])
  r2_scale4<-rating_p4[[2]]/(rating_p4[[2]]+rating_p4_r[[2]])
  pred_score4<-1+r2_scale4+ r3_scale4+ r4_scale4+ r5_scale4
  
  ret<-NULL
  ret[[1]]<-pred_score2
  ret[[2]]<-pred_score3
  ret[[3]]<-pred_score4
  names(ret)<-c('Item cold','User cold','Both cold')
  return(ret)
  
}



