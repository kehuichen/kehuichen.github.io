This is an implementation of the Zero Imputation method in recommender system.

Reference Paper: J. Lu and K Chen ``A Zero-imputation approach in recommendation systems with data missing heterogeneously", in Statistica Sinica.

ZeroImpute.R script includes two functions: zeroimpute and zeroimpute_coldstart. The rating scale is 1:K.

zeroImpute <-function(data,p=NULL,K=5,p_candi,u_id=NULL,v_id=NULL) requires the following input,
data: observed rating matrix, in tuple form (user,item,score)
p: latent dimension, if not prodived, it will tune on the grid of p_candi
u_id: user_id on test set
v_id: item_id on test set
The zeroimpute function outputs a predicted vector.

zeroImpute_coldstart requires to input:
data: observed rating matrix
u_fea: old user covariates
v_fea: old item covariates
u_new_fea: new user covariates
v_new_fea: new item covariates
The zeroImpute_coldstart function outputs item-cold, user-cold, and both cold predictions on all entries.
