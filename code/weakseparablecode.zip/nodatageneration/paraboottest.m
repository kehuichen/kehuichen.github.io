function [nonstudparateststat,nonstudparapval] = paraboottest(y,zetamatrix,J,K,Ppara,Kpara,B)

ybar=mean(y,3);

[p,n]=size(zetamatrix);
Sigmaest = (1/n)*(zetamatrix*zetamatrix'); %sample covariance matrix of estimated scores
xi=Sigmaest(triu(true(p,p),1)); %vector of off-diagonal elements

nonstudparateststat=n*sum(xi.^2); %non studentized test statistic

[psi,phi,~,~,~,~] = estimatepsis(y,Ppara,Kpara,0);
zetamatrixpara = zetafrompsis(y,psi,phi); %estimated scores from boostrap sample
Sigmapara = (1/n)*(zetamatrixpara*zetamatrixpara');
V=zeros(Kpara,Ppara);
V(1:end)=diag(Sigmapara);
V=V'; %Estimated variance matrix V (matrix of estimated etas)

nonstudparabootsum = 0;
for b=1:B
    yb = GenerateData2var(ybar, n, psi, phi, V, 0); %resample data with replacement
    [psihat,phihat,~,~,~,~] = estimatepsis(yb,J,K,0);
    zetamatrixestb = zetafrompsis(yb,psihat,phihat); %estimated scores from boostrap sample
    Sigmaestb = (1/n)*(zetamatrixestb*zetamatrixestb'); 
    xib=Sigmaestb(triu(true(p,p),1));
    nonstudparabootstat=n*sum(xib.^2); %non studentized bootstrap test statistic
    nonstudparabootsum = nonstudparabootsum + (nonstudparabootstat>nonstudparateststat);
end

nonstudparapval=nonstudparabootsum/B;