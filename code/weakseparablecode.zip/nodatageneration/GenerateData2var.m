function [x, y, chimatrixtrue] = GenerateData2var(mu, n, psi, phi, eta, sigma)
[p,q] = size(eta);
xi = zeros(p,q,n);
mtps = size(psi,1);
mtpt = size(phi,1);
x = zeros(mtps,mtpt,n); %underlying function
y = zeros(mtps,mtpt,n); %observations
for i = 1:n
    xi(:,:,i) = sqrt(eta).* randn(p,q);  
    x(:,:,i) = mu;
    for j=1:p
        for k=1:q
        x(:,:,i) =x(:,:,i) + xi(j,k,i)*psi(:,j)*transpose(phi(:,k));
        end
    end
    y(:,:,i) = x(:,:,i)+ sigma*randn(mtps,mtpt);
end
chimatrixtrue=xi;