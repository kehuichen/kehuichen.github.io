function cellarray = calccellarray2(indices,lambdahat,gammahat,alpha)

j=indices(1);
k=indices(2);
jp=indices(3);
kp=indices(4);

%case 1
if (j~=jp) && (k~=kp)
   cellarray=cell(1,2);
   cellarray{1,1}=[1 j jp];
   cellarray{1,2}=[1 k kp];
    
%case 2
elseif (j==jp) && (k~=kp)
    cellarray=cell(3,2);
    cellarray{1,1}=[1 j jp];
    cellarray{1,2}=[1 k kp];
    cellarray{2,1}='I';
    cellarray{2,2}=[alpha(j,kp)*(1/(gammahat(k)-gammahat(kp))) k kp];
    cellarray{3,1}='I';
    cellarray{3,2}=[alpha(j,k)*(1/(gammahat(kp)-gammahat(k))) kp k];
    
%case 3
else
    cellarray=cell(3,2);
    cellarray{1,1}=[1 j jp];
    cellarray{1,2}=[1 k kp];
    cellarray{2,1}=[alpha(j,k)*(1/(lambdahat(jp)-lambdahat(j))) jp j];
    cellarray{2,2}='I';
    cellarray{3,1}=[alpha(jp,k)*(1/(lambdahat(j)-lambdahat(jp))) j jp];
    cellarray{3,2}='I';
end