% function [pval,teststat,Pn,Kn,FVE] = weakseptest(X,test,testopts,dimensions)
% This is the main function for the test of weak separability. 
% Reference: A Test of Weak Separability for Multi-way Functional Data, with Application to Brain Connectivity Studies
% by Brian Lyncha and Kehui Chen
% This code only works for dense regular data. 
% The method developed in the paper could work for more flexible designs
% with a modified version of this code.

%Input: 
% X: The dataset, in which the data X_i(s,t), i=1,...,n, is stored as an
%   array of dimension d1+d2+1, where the first d1 dimensions correspond to s,
%   the following d2 dimensions correspond to t, and the last dimension
%   corresponds to i. The data is assumed to be dense and equally spaced.
% test: The test procedure. Set to 'chi2' to use chi^2 type mixture
%   approximation, set to 'emp' to use empirical bootstrap, set to 'para' to
%   use parametric bootstrap.
% testopts: Options for performing the test.
%   testopts.method: Method to choose the number of estimated
%       eigenfunctions P_n and K_n. Set to 'FVE' to determine P_n and K_n using
%       the FVE rule (see Section 3.2 of the paper). Set to 'direct' to specify
%       P_n and K_n using testopts.Pn and testopts.Kn.
%   testopts.Pnfull: Largest j such that the marginal projection scores \chi_{jk}
%       can be reasonably considered nonzero. Must be <= to the number of 
%       s gridpoints.
%   testopts.Knfull: Largest k such that the marginal projection scores \chi_{jk}
%       can be reasonably considered nonzero. Must be <= to the number of 
%       t gridpoints.
%   testopts.Pn: When using testopts.method='direct', this is the value of P_n. 
%       It should be <= to testopts.Pnfull.
%   testopts.Kn: When using testopts.method='direct', this is the value of K_n. 
%       It should be <= to testopts.Knfull.
%   testopts.B: Number of bootstrap re-samples.
% dimensions: [d1,d2], the dimensions of the arguments s and t,
%   respectively.

% Output: 
% pval: The P-value for the test
% teststat: The test statistic S_n
% Pn: The number of estimated eigenfunctions P_n used for the test
% Kn: The number of estimated eigenfunctions K_n used for the test
% FVE: FVE(P_n,K_n) - see Section 3.2 of the paper

function [pval,teststat,Pn,Kn,FVE]=weakseptest(X,test,testopts,dimensions)

if isempty(dimensions)
    dimensions=[1,1];
end

%Vectorize the arguments of X_i(s,t) so s and t can be treated as 1D
d1=dimensions(1);
d2=dimensions(2);
dimsize=size(X);
n=dimsize(end);
mtps=prod(dimsize(1:d1));
mtpt=prod(dimsize((d1+1):(d1+d2)));
X=reshape(X(:),mtps,mtpt,n);

if isempty(testopts)
    testopts.method='FVE';
    testopts.Pnfull=min([n floor(mpts/2)]);
    testopts.Knfull=min([n floor(mtpt/2)]);
    testopts.B=1000;
end

if isempty(test)
    test='chi2';
end

Pnfull=testopts.Pnfull;
Knfull=testopts.Knfull;

if strcmp(testopts.method,'FVE')
    
    FVEcutoff=.85; %Chooses number of estimated eigenfunctions < or = to Pest and Kest to use for each trial. Set =0 to use the values set by Pest and Kest for all trials
    good=0;
    while good==0 && FVEcutoff<.95
    FVEcutoff=FVEcutoff+.05;

    %Get estimated zeta values
    [psihat,phihat,lambdahat,gammahat,Pn,Kn] = estimatepsis(X,Pnfull,Knfull,FVEcutoff);
    [zetamatrixest,~] = zetafrompsis(X,psihat,phihat);

    %FVE
    FVE=FVEcalcs(zetamatrixest,Pn,Kn,Pnfull,Knfull,X);

        if FVE >= .90
        good=1;
        end
    end
    
elseif strcmp(testopts.method,'direct')
    %Get estimated zeta values
    [psihat,phihat,lambdahat,gammahat,Pn,Kn] = estimatepsis(X,testopts.Pn,testopts.Kn,0);
    [zetamatrixest,~] = zetafrompsis(X,psihat,phihat);

    %FVE
    FVE=FVEcalcs(zetamatrixest,Pn,Kn,Pnfull,Knfull,X);
   
end

if strcmp(test,'chi2')
    
    %Estimate "all" eigenfunctions/eigenvalues
    [psihatfull,phihatfull,~,~,~,~] = estimatepsis(X,Pnfull,Knfull,0);
    [~,chiestfull] = zetafrompsis(X,psihatfull,phihatfull);

    %Mixture chi-square test using true covariance
    [teststat,pval]=mixturechi2test(Pn,Kn,chiestfull,lambdahat,gammahat);

    
elseif strcmp(test,'emp')
    %Test using empirical bootstrap
    [teststat,pval] = empboottest(X,psihat,phihat,zetamatrixest,Pn,Kn,testopts.B);

    
elseif strcmp(test,'para')
    %Test using parametric bootstrap
    [teststat,pval] = paraboottest(X,zetamatrixest,Pn,Kn,Pnfull,Knfull,testopts.B);

    
end


