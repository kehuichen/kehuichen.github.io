function [nonstudempteststat,nonstudemppval] = empboottest(y,psi,phi,zetamatrix,J,K,B)

[p,n]=size(zetamatrix);
Sigmaest = (1/n)*(zetamatrix*zetamatrix'); %sample covariance matrix of estimated scores
xi=Sigmaest(triu(true(p,p),1)); %vector of off-diagonal elements

nonstudempteststat=n*sum(xi.^2); %non studentized test statistic

nonstudempbootsum = 0;
for b=1:B
    yb = datasample(y,n,3); %resample data with replacement
    [psihat,phihat,~,~,~,~] = estimatepsis(yb,J,K,0);
    
    % change signs of bootstrap eigenfunctions to match those of
    % eigenfunctions from data
    for i=1:J
        diff=sum((psi(:,i)-psihat(:,i)).^2);
        diffopp=sum((psi(:,i)+psihat(:,i)).^2);
        if diffopp<diff
            psihat(:,i)=-psihat(:,i);
        end
    end
    for i=1:K
        diff=sum((phi(:,i)-phihat(:,i)).^2);
        diffopp=sum((phi(:,i)+phihat(:,i)).^2);
        if diffopp<diff
            phihat(:,i)=-phihat(:,i);
        end
    end
    
    zetamatrixestb = zetafrompsis(yb,psihat,phihat); %estimated scores from boostrap sample
    Sigmaestb = (1/n)*(zetamatrixestb*zetamatrixestb'); 
    xib=Sigmaestb(triu(true(p,p),1));

    nonstudempbootstat=n*sum((xib-xi).^2); %non studentized bootstrap test statistic
    nonstudempbootsum = nonstudempbootsum + (nonstudempbootstat>nonstudempteststat);
end

nonstudemppval=nonstudempbootsum/B;