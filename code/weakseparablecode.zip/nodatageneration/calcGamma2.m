function Gammaentry = calcGamma2(indices1,indices2,chiestfull,lambdahat,gammahat,alpha)

cellarray1=calccellarray2(indices1,lambdahat,gammahat,alpha); %calculates A_1's and A_2's depending on the 3 cases
cellarray2=calccellarray2(indices2,lambdahat,gammahat,alpha); %calculates B_1's and B_2's depending on the 3 cases

dim1=size(cellarray1,1);
dim2=size(cellarray2,1);
Ematrix=zeros(dim1,dim2);
for j=1:dim1
    for k=1:dim2
        Ematrix(j,k)=Efcn2(cellarray1{j,1},cellarray1{j,2},cellarray2{k,1},cellarray2{k,2},chiestfull); %computes Tr in Eqn 15
    end
end

Gammaentry=sum(sum(Ematrix));
