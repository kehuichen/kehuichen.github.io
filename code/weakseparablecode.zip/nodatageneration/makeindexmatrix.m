function indexmatrix = makeindexmatrix(Pn,Kn)

indexes=zeros(Pn*Kn,2);
counter=1;
for j=1:Pn
    for k=1:Kn
        indexes(counter,:)=[j k];
        counter=counter+1;
    end
end

indexmatrix=zeros(Pn*Kn*(Pn*Kn-1)/2,4);
counter=1;
for j=1:(Pn*Kn-1)
    for k=(j+1):(Pn*Kn)
        indexmatrix(counter,:)=[indexes(j,:) indexes(k,:)];
        counter=counter+1;
    end
end


