function Evalue=Efcn2(A1,A2,B1,B2,chiestfull)

[Pnfull, Knfull, n]=size(chiestfull);

indicators = [ischar(A1) ischar(A2) ischar(B1) ischar(B2)];

if sum(indicators==[0 0 0 0])==4
    j1=A1(2);
    j1p=A1(3);
    k1=A2(2);
    k1p=A2(3);
    j2=B1(2);
    j2p=B1(3);
    k2=B2(2);
    k2p=B2(3);
    Evalue=A1(1)*A2(1)*B1(1)*B2(1)*(1/n)*sum(chiestfull(j1,k1,:).*chiestfull(j1p,k1p,:).*chiestfull(j2,k2,:).*chiestfull(j2p,k2p,:),3);
elseif sum(indicators==[1 0 0 0])==4
    k1=A2(2);
    k1p=A2(3);
    j2=B1(2);
    j2p=B1(3);
    k2=B2(2);
    k2p=B2(3);
    Evalue=0;
    for i=1:Pnfull
        Evalue=Evalue+(1/n)*sum(chiestfull(i,k1,:).*chiestfull(i,k1p,:).*chiestfull(j2,k2,:).*chiestfull(j2p,k2p,:),3);
    end
    Evalue=A2(1)*B1(1)*B2(1)*Evalue;
elseif sum(indicators==[0 1 0 0])==4
    j1=A1(2);
    j1p=A1(3);
    j2=B1(2);
    j2p=B1(3);
    k2=B2(2);
    k2p=B2(3);
    Evalue=0;
    for ip=1:Knfull
        Evalue=Evalue+(1/n)*sum(chiestfull(j1,ip,:).*chiestfull(j1p,ip,:).*chiestfull(j2,k2,:).*chiestfull(j2p,k2p,:),3);
    end
    Evalue=A1(1)*B1(1)*B2(1)*Evalue;
elseif sum(indicators==[0 0 1 0])==4
    j1=A1(2);
    j1p=A1(3);
    k1=A2(2);
    k1p=A2(3);
    k2=B2(2);
    k2p=B2(3);
    Evalue=0;
    for k=1:Pnfull
        Evalue=Evalue+(1/n)*sum(chiestfull(j1,k1,:).*chiestfull(j1p,k1p,:).*chiestfull(k,k2,:).*chiestfull(k,k2p,:),3);
    end
    Evalue=A1(1)*A2(1)*B2(1)*Evalue; 
elseif sum(indicators==[0 0 0 1])==4
    j1=A1(2);
    j1p=A1(3);
    k1=A2(2);
    k1p=A2(3);
    j2=B1(2);
    j2p=B1(3);
    Evalue=0;
    for kp=1:Knfull
        Evalue=Evalue+(1/n)*sum(chiestfull(j1,k1,:).*chiestfull(j1p,k1p,:).*chiestfull(j2,kp,:).*chiestfull(j2p,kp,:),3);
    end
    Evalue=A1(1)*A2(1)*B1(1)*Evalue;
elseif sum(indicators==[1 0 1 0])==4
    k1=A2(2);
    k1p=A2(3);
    k2=B2(2);
    k2p=B2(3);
    Evalue=0;
    for i=1:Pnfull
        for k=1:Pnfull
            Evalue=Evalue+(1/n)*sum(chiestfull(i,k1,:).*chiestfull(i,k1p,:).*chiestfull(k,k2,:).*chiestfull(k,k2p,:),3);
        end
    end
    Evalue=A2(1)*B2(1)*Evalue;
elseif sum(indicators==[1 0 0 1])==4
    k1=A2(2);
    k1p=A2(3);
    j2=B1(2);
    j2p=B1(3);
    Evalue=0;
    for i=1:Pnfull
        for kp=1:Knfull
            Evalue=Evalue+(1/n)*sum(chiestfull(i,k1,:).*chiestfull(i,k1p,:).*chiestfull(j2,kp,:).*chiestfull(j2p,kp,:),3);
        end
    end
    Evalue=A2(1)*B1(1)*Evalue;
elseif sum(indicators==[0 1 1 0])==4
    j1=A1(2);
    j1p=A1(3);
    k2=B2(2);
    k2p=B2(3);
    Evalue=0;
    for ip=1:Knfull
        for k=1:Pnfull
            Evalue=Evalue+(1/n)*sum(chiestfull(j1,ip,:).*chiestfull(j1p,ip,:).*chiestfull(k,k2,:).*chiestfull(k,k2p,:),3);
        end
    end
    Evalue=A1(1)*B2(1)*Evalue;
elseif sum(indicators==[0 1 0 1])==4
    j1=A1(2);
    j1p=A1(3);
    j2=B1(2);
    j2p=B1(3);
    Evalue=0;
    for ip=1:Knfull
        for kp=1:Knfull
            Evalue=Evalue+(1/n)*sum(chiestfull(j1,ip,:).*chiestfull(j1p,ip,:).*chiestfull(j2,kp,:).*chiestfull(j2p,kp,:),3);
        end
    end
    Evalue=A1(1)*B1(1)*Evalue;
end

