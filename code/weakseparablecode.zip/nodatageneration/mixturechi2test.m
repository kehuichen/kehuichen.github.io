function [Sn,pval] = mixturechi2test(Pn,Kn,chiestfull,lambdahat,gammahat)

n=size(chiestfull,3);

indexmatrix=makeindexmatrix(Pn,Kn); %each row is a [j k j' k']

vectlength=size(indexmatrix,1);
Tnvect=zeros(vectlength,1); %vector of all the Tn(j, k, j', k')
for m=1:vectlength
    Tnvect(m,1)=(1/sqrt(n))*sum(chiestfull(indexmatrix(m,1),indexmatrix(m,2),:).*chiestfull(indexmatrix(m,3),indexmatrix(m,4),:),3);
end

alpha=(1/n)*sum(chiestfull.^2,3); %matrix of estimated variances of scores

%calculate covariance matrix Gamma
Gamma=zeros(vectlength,vectlength);
for j=1:vectlength
    for k=j:vectlength
        Gamma(j,k)=calcGamma2(indexmatrix(j,:),indexmatrix(k,:),chiestfull,lambdahat,gammahat,alpha);
    end
end
for j=2:vectlength
    for k=1:(j-1)
        Gamma(j,k)=Gamma(k,j);
    end
end

Sn=sum(Tnvect.^2);

beta = trace(Gamma*Gamma)/trace(Gamma);
d = (trace(Gamma))^2/trace(Gamma*Gamma);

pval = chi2cdf(Sn/beta,d,'upper');