function [psihat,phihat,lambdahat,gammahat,J,K] = estimatepsis(y,Pest,Kest,FVEcutoff)

[mtps,mtpt,n]=size(y);

%estimate the psis and phis from the data

%center data
ybar=mean(y,3); %sample mean
for i=1:n
    y(:,:,i)=y(:,:,i)-ybar;
end

%get estimated eigenfunctions from estimated marginal covariances
margcov1=zeros(mtps,mtps); %This is estimated C_s
margcov2=zeros(mtpt,mtpt); %This is estimated C_t
for i=1:n
   margcov1=margcov1+y(:,:,i)*transpose(y(:,:,i));
   margcov2=margcov2+transpose(y(:,:,i))*y(:,:,i);
end
margcov1=(1/n)*margcov1;
margcov2=(1/n)*margcov2;
margcov1=(margcov1+margcov1')/2; %eliminate possible lack of symmetry due to roundoff error
margcov2=(margcov2+margcov2')/2;

if Pest<mtps && Kest<mtpt
[psihat,lambdahat]=eigs(margcov1,Pest); %columns of psihat are estimated psi
[phihat,gammahat]=eigs(margcov2,Kest); %columns of phihat are estimated phi
lambdahat=diag(lambdahat); %estimated eigenvalues
gammahat=diag(gammahat); %estimated eigenvalues
else
[psihat,lambdahat]=eig(margcov1); %columns of psihat are estimated psi
[phihat,gammahat]=eig(margcov2); %columns of phihat are estimated phi
lambdahat=diag(lambdahat); %estimated eigenvalues
gammahat=diag(gammahat); %estimated eigenvalues
if lambdahat(mtps)>lambdahat(1)
    lambdahat=lambdahat(mtps:-1:(mtps-Pest+1));
    psihat=psihat(:,mtps:-1:(mtps-Pest+1));
end
if gammahat(mtpt)>gammahat(1)
    gammahat=gammahat(mtpt:-1:(mtpt-Kest+1));
    phihat=phihat(:,mtpt:-1:(mtpt-Kest+1));
end
end

if FVEcutoff==0
    J=Pest;
    K=Kest;
else
%Determine number of estimated eigenfunctions to use based on marginal FVEs
FVEs=0;
J=0;
while FVEs<FVEcutoff
J=J+1;
% FVEs=sum(lambdahat(1:J))/trace(margcov1);
FVEs=sum(lambdahat(1:J))/sum(lambdahat);
end

FVEt=0;
K=0;
while FVEt<FVEcutoff
K=K+1;
% FVEt=sum(gammahat(1:K))/trace(margcov2);
FVEt=sum(gammahat(1:K))/sum(gammahat);
end

psihat=psihat(:,1:J);
phihat=phihat(:,1:K);
end