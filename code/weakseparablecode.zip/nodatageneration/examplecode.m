%%%%%%%%%%%%%%%%%%%%%%
%Load example data
load X.mat %A 20x20x100 array of data X_i(s,t), i=1,...,100, s=1,...,20, t=1,...,20


%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Test for weak separability
test = 'chi2'; %Set to 'chi2' to use chi^2 type mixture approximation, set to 'emp' to use empirical bootstrap, set to 'para' to use parametric bootstrap

testopts.method = 'FVE'; %Set to 'FVE' to determine P_n and K_n using the FVE rule. Set to 'direct' to use P_n and K_n specified by testopts.Pn and testopts.Kn
% testopts.Pn = 3; %When using testopts.method='direct', this is the value of P_n. It should be <= testopts.Pnfull
% testopts.Kn = 2; %When using testopts.method='direct', this is the value of K_n. It should be <= testopts.Knfull
testopts.Pnfull = 3; %Largest j such that the marginal projection scores \chi_{jk} can be reasonably considered nonzero.
testopts.Knfull = 3; %Largest k such that the marginal projection scores \chi_{jk} can be reasonably considered nonzero.
testopts.B = 1000; %Number of bootstrap re-samples

d1=1; %dimension of the argument s
d2=1; %dimension of the argument t

[pvalue,teststat,Pn,Kn,FVE] = weakseptest(X,test,testopts,[d1,d2]); %Test for weak separability. Outputs the P-value, S_n, P_n, K_n, and FVE(P_n,K_n). 
%X is the dataset, in which the data X_i(s,t), i=1,...,n, is stored as an
%array of dimension d1+d2+1, where the first d1 dimensions correspond to s,
%the following d2 dimensions correspond to t, and the last dimension
%corresponds to i. The data is assumed to be dense and equally spaced.

