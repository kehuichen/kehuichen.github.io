1. This package performs the test of weak separability

2. Reference: A Test of Weak Separability for Multi-way Functional Data, with Application to Brain Connectivity Studies, by Brian Lynch and Kehui Chen.

3. The main function is weakseptest(). A detailed description of this function can be found in the file weakseptest.m

4. Example code is given in examplecode.m. 
