function FVE=FVEcalcs(zetamatrixest,Pest,Kest,Pestfull,Kestfull,y)

[mtps,mtpt,n]=size(y);

%center data
ybar=mean(y,3); %sample mean
for i=1:n
    y(:,:,i)=y(:,:,i)-ybar;
end

Sigmaest = (1/n)*(zetamatrixest*zetamatrixest'); %Estimated Sigma
V=zeros(Kest,Pest);
V(1:end)=diag(Sigmaest);
V=V'; %Estimated variance matrix V

%Get scores from all phis and psis
[psihat,phihat,~,~,Pestnew,Kestnew] = estimatepsis(y,Pestfull,Kestfull,0);   
zetamatrixestfull = zetafrompsis(y,psihat,phihat);
Sigmaestfull = (1/n)*(zetamatrixestfull*zetamatrixestfull'); %Estimated Sigma
Vfull=zeros(Kestnew,Pestnew);
Vfull(1:end)=diag(Sigmaestfull);
Vfull=Vfull'; %Estimated variance matrix V

FVE=sum(sum(V))/sum(sum(Vfull));

