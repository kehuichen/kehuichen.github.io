load trafficforsimu.mat
nsimu = 400;
ntest = 100;
ntrain = 300;
errx = 1;
erry = 1;

paramC = 2.5;
GCV = 0;
kern = [];
level = 0.9; 

param_X = setOptions('regular', 2, 'bwmu', 0.2, 'bwxcov', [0.2, 0.2], 'method', 'IN', 'verbose', 'off');
param_Y = setOptions('regular', 2, 'bwmu',8, 'bwxcov', [6, 6], 'method', 'IN', 'verbose', 'off');

[x, t_x, y, t_y] = SimulateXY(nsimu, 'gaussian', errx, erry, outx, outy, phix, phiy, mux, muy,lambdax,lambday, K_x, K_y, spcx, mean_fxi, cov_fxi);
isNewSub = zeros(1, nsimu);
isNewSub((ntrain+1):nsimu)=1;
[res_FPCA, res_FQuantfit, res_FQuantpred, out_y, predregionsL, predregionsU] ...
= FFPredRegions(x,t_x,y,t_y, param_X, param_Y, K_x, K_y, level, paramC, isNewSub);

a = mysample(1:ntest, 4, 0);
for k = 1: 4
    i = a(k);
    itotal = ntrain+i;
    subplot(2,2,k)
    plot(t_y{itotal}, y{itotal}, 'r')  % plot the true y curve
     hold on
    plot(out_y, predregionsL(i,:))  % plot the simultaneous 90% prediction regions. 
    plot(out_y, predregionsU(i,:))
end
 
 