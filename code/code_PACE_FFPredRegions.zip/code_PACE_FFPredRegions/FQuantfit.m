function res_FQuantfit = FQuantfit(res_FPCA, GCV, kern, isNewSub)  
   if isempty(GCV)
       GCV = 0;
   end
   if isempty(kern)
       kern = 'gauss';
   end
   xx = getVal(res_FPCA, 'xx');
   yy = getVal(res_FPCA, 'yy');
   K_x = getVal(res_FPCA, 'K_x');
   K_y = getVal(res_FPCA, 'K_y');
   out1y = getVal(yy, 'out1');
   muy = getVal(yy, 'mu');
   phiy = getVal(yy, 'phi');
   out21y = getVal(yy, 'out21');
   
   pcx = getVal(xx,'xi_est');
   pcy = getVal(yy,'xi_est'); 
   if ~isempty(isNewSub)
       pcx = pcx(isNewSub==0, :);
       pcy = pcy(isNewSub==0, :);
   end
   nn = size(pcx,1);
   % functional additive model for mean_fxi
     mubw = zeros(1, K_x);
     for i = 1: K_x
         if GCV == 1 
            mubw(i) = gcv_lwls(pcy(:,1)',pcx(:,i)',kern,1,1,0,2, 'off');           
         else 
            mubw(i) = range(pcx(:,i))/10; 
         end
     end   
     mean_fxi = cell(K_x, K_y);
     win = ones(1,nn);
     spcx = cell(1,K_x);
     for i = 1:K_x
         spcx{i} = unique(sort(pcx(:,i)));
         for j = 1:K_y
             [invalid,tmp] = lwls(mubw(i),kern,1,1,0,pcx(:,i)',pcy(:,j),win, spcx{i});
             if (invalid == 0)
                  mean_fxi{i,j} = tmp';
             else
                  error('bw is too small')
             end
         end
     end
     
  %functional additive model for cov_fxi
   lambday = getVal(yy, 'lambda');
   covbw = zeros(K_x,1);
   for i = 1: K_x
        if GCV == 1
            covbw(i) = gcv_lwls(pcy(:,1).^2'-lambday(1),pcx(:,i)',kern,1,1,0,2, 'off');
        end
            covbw(i) = range(pcx(:,i))/5;
   end
   cov_fxi = cell(K_x, K_y);
   win = ones(1, nn);
   for i = 1:K_x
       for j = 1:K_y        
           [invalid,tmp] = lwls(covbw(i),kern,1,1,0,pcx(:,i)',pcy(:,j).^2 - lambday(j), win ,spcx{i});
           cov_fxi{i,j} = max(tmp, -lambday(j))'; %nonnegative of E(pcy^2|pcx)
           ids = find(mean_fxi{i,j} < 0);
           mean_fxi{i,j} = min(sqrt(cov_fxi{i,j}+lambday(j)), abs(mean_fxi{i,j})); %nonnegative of var(pcy|pcx)
           mean_fxi{i,j}(ids) = -mean_fxi{i,j}(ids);
       end
   end 
   
   % fitted mean and cov
   pcyvarfit = zeros(nn, K_y);
   covfxi = zeros(nn, K_x);
   pcyfit = zeros(nn, K_y);
   meanfxi = zeros(nn, K_x); 
   threshold = lambday/100;
   for j = 1:K_y
       for i = 1:K_x
           meanfxi(:,i) = interp1(spcx{i},mean_fxi{i,j} ,pcx(:,i),'spline');
           covfxi(:,i) = interp1(spcx{i}, cov_fxi{i,j}, pcx(:,i), 'spline');
       end
       pcyfit(:,j) = sum(meanfxi, 2);
       pcyvarfit(:,j) = lambday(j)+ sum(covfxi-meanfxi.^2, 2);
       pcyvarfit(:,j) = max(pcyvarfit(:,j), threshold(j)); 
   end
  
   meanfitted = mat2cell(repmat(muy,nn,1)+pcyfit*phiy',ones(1,nn))'; 
   
   
   phiyfit = interp1(out1y',phiy, out21y','spline');  
   covfitted = cell(1, nn);
   for i = 1:nn
       cov_i = phiyfit*diag(pcyvarfit(i,:))*phiyfit';            
       cov_i = (cov_i+cov_i')/2;
       opts.disp = 0;  %don't show the intermediate steps
       ngrid = size(cov_i,1);
       [eigen lambda] = eigs(cov_i,ngrid-2,'lm',opts);
       lambda = diag(lambda);
       eigen = eigen(:, lambda>0);
       lambda = lambda(lambda>0);
       covfitted{i} = eigen*diag(lambda)*eigen';      
   end   
   
    varfit = cell(1,nn);
    for i = 1:nn
        varfit{i} = max(interp1(out21y, diag(covfitted{i}), out1y),0);
    end
        
   resNames = {'res_FPCA', 'spcx', 'mean_fxi', 'cov_fxi', 'pcyfit','pcyvarfit', 'meanfitted', 'covfitted', 'varfit'};
   res_FQuantfit = {res_FPCA,  spcx, mean_fxi, cov_fxi, pcyfit, pcyvarfit, meanfitted, covfitted, varfit, resNames};
end