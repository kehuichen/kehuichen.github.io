function [C ]= cvChooseC(x, t_x, y, t_y, param_X, param_Y, K_x, K_y, level)
  n = length(x);
  isNewSub = zeros(1, n);
  meanpred = cell(1,n);
  varpred = cell(1,n);
  [res_FPCA] = twoFPCA(x, t_x, y, t_y, param_X, param_Y, K_x, K_y);
  xx = getVal(res_FPCA, 'xx');
  yy = getVal(res_FPCA, 'yy');
  pcx= getVal(xx,'xi_est');
  y_pred = getVal(yy, 'y_pred');
  for i = 1:n
      isNewSub(i) = 1;
      newx = x(isNewSub==1);
      newtx = t_x(isNewSub==1);
      newty = t_y(isNewSub==1);
      newy = y(isNewSub==1);
      newpcx = pcx(isNewSub==1, :);
      ypred = y_pred(isNewSub==1);
      res_FQuantfit = FQuantfit(res_FPCA, [], [], isNewSub);
      [res] = FQuantpred(newx, newtx, newy, res_FQuantfit); 
      meanpred(i) = getVal(res, 'meanpred');
      varpred(i)= getVal(res, 'varpred');
      isNewSub(i) = 0;
  end
  C = ChooseC(meanpred, varpred, y_pred, level);
end
