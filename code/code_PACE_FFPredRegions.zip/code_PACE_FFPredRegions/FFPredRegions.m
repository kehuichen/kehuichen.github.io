% ============
% Description:
% ============
% 
% This is the main function to implement the conditional distribution modeling for functional response,
% with functional covariates, 
% 
% Reference: K Chen,  H.G. Mueller (2014) Modeling Conditional Distributions For
% Functional Responses, With Application to Traffic Monitoring via GPS-enabled Mobile
% Phones. Techonometrics.
% 
% Includes the following steps:
% 
% (1). twoFPCA:  perform functional principal component analysis for response functions Y(t) and predictor functions X(s).
% (2). FQuantfit: train the model.
% (3). FQuantpred: predict conditional mean, conditional covariance for new predictors X(s).
% (4). Find the suitable C value and Compute prediction regions.
% 
% ========
% Usage:
% ========
% 
% [FF_res] = FFPredRegions(x, t_x, y,t_y, param_X, param_Y, K_x, K_y, level, paramC, isNewSub, )
% 
% =======
% Input:
% =======
% 
% x    :   1*n cell array for predictor function x, where x{i} is the row vector of
%          measurements for the ith subject, i=1,...,n. It may contain data for subjects
%          that are used for prediction; this is controlled by "isNewSub".
% 
% t_x  :   1*n cell array, t_x{i} is the row vector of time points for the ith
%          subject at which corresponding measurements x{i} are taken,
%          i=1,...,n. It contains subjects that are used for prediction.
% 
% y    :   i) When no prediction is requested, then y{i} is the response value
%             for the ith subject, i = 1,...,n.
%          ii) When prediction is requested, only those for estimation will
%          be used. 
% t_y :    time points for reponse y,  see also t_x. 
% param_X: an object that is returned by setOptions() that sets the input
%          arguments for FPCA() of the x (predictor) functions.
% param_Y: the options for y, see also param_X.
% K_x, K_y: number of components to use, if [], use FVE selection.
% level   : Desired level for prediction region. If set to [], no prediction
%           region will be provided. 
% paramC  : the value C to be used in constructing prediction regions, if [],
%           cross-validation will be used.
% isNewSub: i) 1*n vector of 0s or 1s, where
% 
%              1 : the data for the corresponding subject, i.e.,
%                  X(isNewSub == 1), t_x(isNewSub==1)
%                  are used for prediction only;
% 
%                 The count is n-nn for subjects with isNewSub = 1.
% 
%              0 : the data for the corresponding subject, i.e.,
%                  X(isNewSub == 0), t_x(isNewSub == 0), y(isNewSub == 0)
%                  are used for estimation only.
% 
%                  The count is nn for subjects with isNewSub = 0
% 
%           This option is convenient for computing leave-one-out
%           prediction if desired.
% 
% 
%          ii) If it is a positive integer, say 5, then the last 5 subjects (in the order from
%              top to bottom within the array x) and their values for
%              t_x are used for prediction. In other words, when choosing
%              this option, one would append the ``new'' subjects for which one desires prediction of the response
%              to occur at the end of x, t_x. Then the first nn rows of the arrays x, t_x and y are used 
%              for estimation and the remainder (last n-nn rows) of x,t_x will be used for prediction.

%           This option is convenient for obtaining predictions for a set of new subjects.
% 
%           iii) set isNewSub = [] for the default value, which is no prediction.
% 
% Details: i) There are no default values for the first 4 arguments, that
%             is, they are always part of the input arguments.
%         ii) Any unspecified or optional arguments can be set to "[]" for
%             default values;
%         (iii) When isNewSub is set to be [], no prediction will be performed and no predictio regions,
%               When level is set to be [], no prediction regions will be
%               computed, only predicted mean and predicted covariance.
%             
% =======
% Output:
% =======
% res_FPCA:       a cell array that contains xx, yy, K_x, K_y, where xx
%                 and yy are values returned from FPCA for x and y.
%                 
% 
% res_FQuantfit: a cell array that contains all returned values from
%                FQuantfit. It includes the fitted conditional mean,
%                conditional covariance. Use names(res_FQuantfit) for details.
%       
% res_FQuantpred: a cell array that contains all returned values from
%                Fquantpred. It includes the predicted mean, predicted
%                covariance for new subjects. Use names(res_FQuantpred) for details.
% out_y:         the final output grid for plotting prediction regions.
% predregionsL:  contains the lower bound of the prediction regions for all
%                 new subjects.
% predregionsU:  contains the upper bound of the prediciotn regions for all
%                new subjects.
% 
%  
%
%               
% 
%    o    See exampleFFPredRegrions.m for an example.
% 

function [res_FPCA, res_FQuantfit, res_FQuantpred, out_y, predregionsL, predregionsU]... 
          = FFPredRegions(x, t_x, y, t_y, param_X, param_Y, K_x, K_y, level, paramC, isNewSub)

   [x, t_x, y, t_y, isYFun, newx, newtx, newy, newty, invalid] = pre(x, t_x, y, t_y, isNewSub);
   nn = length(x);
   n = length(x) + length(newx);
   if invalid == 1
       return;
   end

   if isempty(param_X)
       param_X = setOptions();   %set default for param_X
   end
   if isempty(param_Y)
       param_Y = setOptions();
   end   
   
   %perform FPCA on x and y
  
   res_FPCA = twoFPCA(x, t_x, y, t_y, param_X, param_Y, K_x, K_y); 
   res_FQuantfit = FQuantfit(res_FPCA, [], [], []);
  
   
   if ~isempty(newx)
       res_FQuantpred = FQuantpred(newx,newtx,newty, res_FQuantfit);
       meanpred = getVal(res_FQuantpred, 'meanpred');
       varpred= getVal(res_FQuantpred, 'varpred');
       out_y = getVal(res_FQuantpred, 'new_out1');
       if isempty(paramC)
          paramC = cvChooseC(x, t_x, y, t_y, param_X, param_Y, K_x, K_y, level);
       end
       predregionsL = cell2mat(meanpred')- paramC*sqrt(cell2mat(varpred'));
       predregionsU =  cell2mat(meanpred')+ paramC*sqrt(cell2mat(varpred'));
       
   else
        res_FQuantpred = [];
        out_y = [];
        predregionsL = [];
        predregionsU = [];
   end
   
   
   
