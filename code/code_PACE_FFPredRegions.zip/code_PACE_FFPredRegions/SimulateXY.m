function [x t_x y t_y pcy] = SimulateXY(nsimu, probtype, errx, erry, outx,outy, phix, phiy, mux, muy,lambdax,lambday, K_x, K_y,spcx, mean_fxi, cov_fxi)
mx = length(outx);
my = length(outy);
pcx = sqrt(repmat(lambdax, nsimu, 1)).* randn(nsimu, K_x);
xmat = repmat(mux,nsimu, 1)+pcx*phix'+ errx*randn(nsimu, mx);
x = mat2cell(xmat, ones(1,nsimu), mx)';
t_x  = mat2cell(repmat(outx, nsimu, 1), ones(1, nsimu), mx)';

pcyvarfit = zeros(nsimu, K_y);
covfxi = zeros(nsimu, K_x);
pcyfit = zeros(nsimu, K_y);
meanfxi = zeros(nsimu, K_x); 
threshold = lambday/100;
for j = 1:K_y
    for i = 1:K_x
         meanfxi(:,i) = interp1(spcx{i},mean_fxi{i,j} ,pcx(:,i),'spline');
         covfxi(:,i) = interp1(spcx{i}, cov_fxi{i,j}, pcx(:,i), 'spline');
    end
    pcyfit(:,j) = sum(meanfxi, 2);
    pcyvarfit(:,j) = lambday(j)+ sum(covfxi-meanfxi.^2, 2);
    pcyvarfit(:,j) = max(pcyvarfit(:,j), threshold(j)); 
end

switch probtype
    case 'gaussian'
        pcy = sqrt(pcyvarfit).*randn(nsimu, K_y);
    case 'mixture'
        u = rand(nsimu, K_y);
        pcy = sqrt(pcyvarfit/5).*(randn(nsimu, K_y) + 4*(u>0.5)-2);
    case 'gamma'
        pcy = sqrt(pcyvarfit/4).*(randg(4, nsimu, K_y)-4);
end
meanfitted = repmat(muy,nsimu,1)+pcyfit*phiy'; 
ymat = meanfitted + pcy * phiy' + erry*randn(nsimu, my);
y = mat2cell(ymat, ones(1,nsimu), my)';
t_y = mat2cell(repmat(outy, nsimu, 1), ones(1, nsimu), my)';

