%[res] = twoFPCA(x, t_x, y, t_y, param_X, param_Y, K_x, K_y)
%This function calls FPCA.m.
%======
%Input: 
%======
%      x, y:       1*n cell array, y{i} is the vector of measurements for the ith subject,
%                  i=1,...,n.
%      t_x, t_y:   1*n cell array, t_y{i} is the vector of time points for the ith subject on which
%                  corresponding measurements y_y{i} are taken, i=1,...,n.
%      param_X, param_Y:   a struct obtained from setOptions.m sets the rest of arguments for FPCA.m
%      K_x, K_y:    the number of components to use.
%                  
%=======
%Output:  
%=======  
%      res:         a cell array that contains xx, yy, K_x, K_y, where xx
%                   and yy are values returned from FPCA for x and y. 


function [res] = twoFPCA(x, t_x, y, t_y, param_X, param_Y, K_x, K_y)
   if isempty(param_X)
       param_X = setOptions();   %set default for param_X
   end
   if ~isempty(K_x)
       if K_x > 0
           param_X.selection_k = K_x;
       else
           fprintf(1,'Warning: K_x must be a positive integer, reset selection_k to FVE now\n');
           param_X.selection_k = 'FVE';
       end      
   else
       param_X.selection_k = 'FVE';
   end
   
  
   xx = FPCA(x, t_x, param_X);   %perform PCA on x
   K_x  = getVal(xx, 'no_opt');
   
   if isempty(param_Y)
           param_Y = setOptions();   %set default for param_Y
   end
   if ~isempty(K_y)
       if K_y > 0
           param_Y.selection_k = K_y;
       else
           fprintf(1,'Warning: K_y must be a positive integer, reset selection_k to FVE now\n');
           param_Y.selection_k = 'FVE';
           param_Y.FVE_threshold = 0.9;
       end
   else 
       param_Y.selection_k = 'FVE';
       param_Y.FVE_threshold = 0.9;
   end
   
   yy = FPCA(y, t_y, param_Y);   %perform PCA on y       
   K_y = getVal(yy,'no_opt'); 
  
   resNames = {'xx', 'yy', 'K_x', 'K_y'};
   res = {xx, yy, K_x, K_y, resNames};
end
   
   
   
   
   
       