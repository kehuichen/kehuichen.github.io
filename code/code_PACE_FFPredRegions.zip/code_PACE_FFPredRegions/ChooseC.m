function paramC = ChooseC(meanfitted, covfit, predy, level)
diff = abs(cell2mat(meanfitted')-cell2mat(predy'))./sqrt(cell2mat(covfit'));
paramC = quantile(quantile(diff',0.99), level);

