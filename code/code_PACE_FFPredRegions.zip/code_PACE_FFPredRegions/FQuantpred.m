 function [res] = FQuantpred(newx, new_tx, new_ty, res_FQuantfit) 
       nsub = length(newx);
       mean_fxi = getVal(res_FQuantfit, 'mean_fxi'); 
       cov_fxi = getVal(res_FQuantfit, 'cov_fxi');
       res_FPCA = getVal(res_FQuantfit, 'res_FPCA');
       
       K_x = getVal(res_FPCA, 'K_x');
       K_y = getVal(res_FPCA, 'K_y');
       xx = getVal(res_FPCA, 'xx'); 
       spcx = getVal(res_FQuantfit, 'spcx');
       [xpred,newpcx] = FPCApred(xx,newx,new_tx);
       clear xpred;
       
       
       yy = getVal(res_FPCA, 'yy');
       out1y = getVal(yy, 'out1');
       out21y= getVal(yy, 'out21');
       ngrid = length(out21y);
       muy = getVal(yy, 'mu');
       phiy = getVal(yy, 'phi');
       lambday = getVal(yy, 'lambda');
       
      
       tt = cell2mat(new_ty);
       new_out1y = unique([tt, out1y]);
       new_out21y = linspace(min(new_out1y),max(new_out1y),ngrid);
       
       % mean
       newpcy = zeros(nsub,K_y); 
       newfxi = zeros(nsub,K_x);
       newpcyvar = zeros(nsub,K_y);
       newcovfxi = zeros(nsub,K_x);
       threshold = lambday/100;
       for j = 1:K_y
           for i = 1:K_x
               newfxi(:,i) = interp1(spcx{i}, mean_fxi{i,j}, newpcx(:,i),'spline');
               newcovfxi(:,i) = interp1(spcx{i},cov_fxi{i,j},newpcx(:,i),'spline');
           end
           newpcy(:,j) = sum(newfxi, 2);
           newpcyvar(:,j) = lambday(j)+ sum(newcovfxi-newfxi.^2, 2);
           newpcyvar(:,j) = max(newpcyvar(:,j),threshold(j)); %nonnegative of var(pcy^2|X)
        end
        mu_muy = interp1(out1y,muy,new_out1y,'spline');
        mu_phiy = interp1(out1y',phiy,new_out1y','spline');
        meanpred = mat2cell(repmat(mu_muy,nsub,1)+newpcy*mu_phiy',ones(1,nsub))';

         
        %based on newdata and ngrid
               
        cov_phiy = interp1(out1y',phiy, new_out21y', 'spline');

        covpred = cell(1, nsub);
        for i = 1:nsub
             cov_i = cov_phiy*diag(newpcyvar(i,:))*cov_phiy';                   
             cov_i = (cov_i+cov_i')/2;
             opts.disp = 0;  %don't show the intermediate steps
             ngrid = size(cov_i,1);
             [eigen lambda] = eigs(cov_i,ngrid-2,'lm',opts);
             lambda = diag(lambda);
             eigen = eigen(:, lambda>0);
             lambda = lambda(lambda>0);
             covpred{i} = eigen*diag(lambda)*eigen';  
        end 
   
        varpred = cell(1,nsub);
        for i = 1:nsub
             varpred{i} = max(interp1(new_out21y, diag(covpred{i}), new_out1y, 'spline'), 0);
        end

   resNames = {'meanpred', 'new_out1', 'covpred', 'new_out21', 'varpred'};
   res = {meanpred, new_out1y, covpred, new_out21y, varpred, resNames};
end