
1. The main function is FFPredRegions.m, and the example file is exampleFFPredRegions.m 
  see descriptions in the file.
2. The code depends on the PACE package for functional data analysis. Please download and install that package first. 
3. Reference:  K Chen,  H.G. Mueller (2014) Modeling Conditional Distributions For
Functional Responses, With Application to Traffic Monitoring via GPS-enabled Mobile
Phones. 