
1. This package performs an asymptotic chi-square test for the two-sample mean function testing problem for sparse function data. 

  
2. Please refer to the paper ‘Two-sample Inference For Sparse functional Data’ by Qiyao Wang and Kehui Chen for details.


3. The main function is called ‘SparseTwoSampleTest’. It takes the two sparse functional datasets and several tuning parameters as input. And it provides three outputs, the calculated value of the test statistic, the corresponding p-value, and the selected dimension of the shrinkage projection score vector. Detailed description is included in ‘SparseTwoSampleTest.R’. 

Note that our main function utilize the ‘fpca’ R package provided by paper ‘A geometric approach to maximum likelihood estimation of the functional principal components from sparse longitudinal data’, Peng and Paul 2009. We also make several modifications to their code such that it can be applied to the two-sample testing problem.       


4. An example of how to use this package can be found in ‘example.R’.


