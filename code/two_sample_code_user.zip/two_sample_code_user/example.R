###########################################Generate Data#################################
###function to get a random sample of size k from [0,...,n] without replacement
rdu<-function(n,k){
  sample(0:k,n,replace=F)
}

###Eigenfunctions evalated at grids
grids<-c(0:100)/100

phi_t<-matrix(rep(0,4*101),4,101)
phi_t[1,]<-sqrt(2)*cos((1)*pi*grids)
phi_t[2,]<-sqrt(2)*sin((1)*pi*grids)
phi_t[3,]<-sqrt(2)*cos((2)*pi*grids)
phi_t[4,]<-sqrt(2)*sin((2)*pi*grids)


###Mean functions evalated at grids
xi<-rep(0,4)
for(i in 1:4){
  xi[i]<-(2)^i*i^6
}
xi<-xi/sqrt(sum(xi^2))*3

mu1<-rep(0,length(grids))
for(i in 1:4){
  mu1<-mu1+phi_t[i,]*xi[5-i]
}

#eta quantifies the difference between mu1(t) and mu2(t)
eta <- 0 #0.8, 1.2, 1.6

xi2<-rep(0,4)
for(i in 1:4){
  xi2[i]<-(2-eta)^i*i^6
}
xi2<-xi2/sqrt(sum(xi2^2))*3

mu2<-rep(0,length(grids))
for(i in 1:4){
  mu2<-mu2+phi_t[i,]*xi2[5-i]
}


###function to generate data
generatedata1<-function(n1,n2,ob,M,sigma1,sigma2,a){
  #n1---sample size of group 1
  #n2---sample size of group 2
  #ob---number of observation for each subject
  #M---number of non-zero eigenvalues
  #sigma1---standard deviation of random error(group 1)
  #sigma2---standard deviation of random error(group 2)
  #a----multiplier used in the specification of eigenvalues
  
  lambda1<-rep(0,M)
  for(j in 1:M){
    lambda1[j]<-a*(j+1)^(-2)
  } 
  
  lambda2<-rep(0,M)
  for(j in 1:M){
    lambda2[j]<-a*(j+1)^(-2)
  } 
  
  m<-rep(ob,n1)
  data1<-matrix(rep(0,3*sum(m)),sum(m),3)
  phi1_true<-matrix(rep(0,sum(m)*M),sum(m),M)
  score1<-matrix(rep(0,n1*M),n1,M)
  
  data1[1:m[1],1]<-rep(1,m[1])
  data1[1:m[1],3]<-sort(rdu(m[1],100))/100
  mu11<-mu1[data1[1:m[1],3]*100+1]
  phi<-t(as.matrix(phi_t[,data1[1:m[1],3]*100+1]))
  z1<-rnorm(M,mean=0,sd=1) 
  xi1<-sqrt(lambda1)*z1
  error<-rnorm(m[1],mean=0,sd=sigma1)
  score1[1,]<-xi1
  data1[1:m[1],2]<-t(mu11+phi%*%xi1+error)
  phi1_true[1:m[1],]<-phi
  
  for(i in 2:n1){
    t<-sort(rdu(m[i],100))
    data1[(sum(m[1:(i-1)])+1):(sum(m[1:i])),1]<-rep(i,m[i])
    data1[(sum(m[1:(i-1)])+1):(sum(m[1:i])),3]<-t/100
    mu11<-mu1[t+1]
    phi<-t(as.matrix(phi_t[,t+1]))
    z1<-rnorm(M,mean=0,sd=1) 
    xi1<-sqrt(lambda1)*z1
    error<-rnorm(m[i],mean=0,sd=sigma1)
    score1[i,]<-xi1
    data1[(sum(m[1:(i-1)])+1):(sum(m[1:i])),2]<-t(mu11+phi%*%xi1+error)
    phi1_true[(sum(m[1:(i-1)])+1):(sum(m[1:i])),]<-phi
  }
  
  m2<-rep(ob,n2)
  data2<-matrix(rep(0,3*sum(m2)),sum(m2),3)
  phi2_true<-matrix(rep(0,sum(m2)*M),sum(m2),M)
  score2<-matrix(rep(0,n2*M),n2,M)
  
  data2[1:m2[1],1]<-rep(1,m2[1])
  data2[1:m2[1],3]<-sort(rdu(m2[1],100))/100
  mu22<-mu2[data1[1:m2[1],3]*100+1]
  phi<-t(as.matrix(phi_t[,data1[1:m2[1],3]*100+1]))
  z2<-rnorm(M,mean=0,sd=1) 
  xi2<-sqrt(lambda2)*z2
  error<-rnorm(m2[1],mean=0,sd=sigma2)
  score2[1,]<-xi2
  data2[1:m2[1],2]<-t(mu22+phi%*%xi2+error)
  phi2_true[1:m2[1],]<-phi
  
  for(i in 2:n2){
    t<-sort(rdu(m2[i],100))
    data2[(sum(m2[1:(i-1)])+1):(sum(m2[1:i])),1]<-rep(i,m2[i])
    data2[(sum(m2[1:(i-1)])+1):(sum(m2[1:i])),3]<-t/100
    mu22<-mu2[t+1]
    phi<-t(as.matrix(phi_t[,t+1]))
    z2<-rnorm(M,mean=0,sd=1) 
    xi2<-sqrt(lambda2)*z2
    error<-rnorm(m2[i],mean=0,sd=sigma2)
    score2[i,]<-xi2
    data2[(sum(m2[1:(i-1)])+1):(sum(m2[1:i])),2]<-t(mu22+phi%*%xi2+error)
    phi2_true[(sum(m2[1:(i-1)])+1):(sum(m2[1:i])),]<-phi
  }
  return(list(data1=data1,data2=data2,phi1_true=phi1_true,phi2_true=phi2_true,lambda1=lambda1,lambda2=lambda2,M=M,score1=score1,score2=score2,true_error1=sigma1,true_error2=sigma2,m=m,m2=m2))
}



n1 <- 100#300, 600
n2 <- 100#300, 600
ob <- 4#8
M <- 4
sigma1 <- 0.6#0, 1.2
sigma2 <- 0.6#0, 1.2
a <- 2

result<-generatedata1(n1,n2,ob,M,sigma1,sigma2,a)

#data of group 1(column 1: ID; column 2: Y; column 3: time)
d1<-as.matrix(result[[1]])
#data of group 2(column 1: ID; column 2: Y; column 3: time)
d2<-as.matrix(result[[2]])



##################################Start testing##################################
source("SparseTwoSampleTest.R")
M.set_t <- c(5,4)
r.set_t <- c(4,3)
grid_t <- seq(0,1,1/100)
test_result <- SparseTwoSampleTest(d1, d2, M.set_t, r.set_t, grid_t)
test_result
