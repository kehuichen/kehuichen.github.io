library(MASS)
#############Source all the functions from package 'fpca'
source("fpca_func.R")
source("functions_LocLin.R")
source("functions_EM.R")
source("functions_GenData.R")
source("functions_Optimization.R")

#############Source all modified functions which works for two-sample data
source("fpca_score_fixed.R")
source("functions_LocLin2.R")
source("fpca_func2.R")


#############Main function to conduct the proposed asymptotic chi-square test
SparseTwoSampleTest <- function(data1, data2, M.set, r.set, grid=seq(0,1,1/100)){
  ###############Inputs###################
  ###'data1' is a matrix, which contains sparse functional data from the first group. It contains 3 columns. The first column is the subject id. The second column is the observed values. The third column is the observing times. 
  ###'data2' is a matrix, which contains sparse functional data from the second group. It has the same format as 'data1'.
  ###'M.set', 'r.set' are vectors, which contains all candidate values for M and r as needed in fpca.mle. 
  ###'grid' is a vector contains the grid points at which the estimated eigenfunctions and eigenvalues to be evaluated.
  ###############Outputs###################
  ###'t' is the value of the asymptotic chi-square test 
  ###'p_value' is the corresponding p-value
  ###'p' is the selected dimension of the shrinkage projected score vectors.
  M.set0 <- 4
  r.set0 <- 3
  
  list1<-fpca.mle(data1, M.set0,r.set0, ini.method="EM", basis.method="bs", sl.v=rep(0.5,10), max.step=50,
                  grid.l=grid, grids=grid)
  list2<-fpca.mle(data2, M.set0,r.set0, ini.method="EM", basis.method="bs", sl.v=rep(0.5,10), max.step=50,
                  grid.l=grid, grids=grid)
  
  n1 <- length(unique(data1[,1]))
  n2 <- length(unique(data2[,1]))
  
  for(i in 1:n1){
    data1[data1[,1]==unique(data1[,1])[i],1] <- i
  }
  for(j in 1:n2){
    data2[data2[,1]==unique(data2[,1])[j],1] <- j + n1
  }
  data<-rbind(data1,data2)
  
  list<-fpca.mle2(data, M.set,r.set, ini.method="EM", basis.method="bs", sl.v=rep(0.5,10), max.step=50,
                  grid.l=grid, grids=grid,list1$fitted_mean,list2$fitted_mean,n1,n2)
  
  p<-list$selected_model[2]
  
  fpcs1<-fpca.score.fixed(data1,list$grid,list$fitted_mean,list$eigenvalues,list$eigenfunctions,list$error_var,p)
  fpcs2<-fpca.score.fixed(data2,list$grid,list$fitted_mean,list$eigenvalues,list$eigenfunctions,list$error_var,p)
  
  eigenval1<-list$eigenvalues
  eigenval2<-list$eigenvalues
  
  sigma1<-list$error_var
  sigma2<-list$error_var
  
  l <- length(list$grid) - 1
  phi1 <- matrix(rep(0,p*dim(data1)[1]),dim(data1)[1],p)
  for(i in 1:length(unique(data1[,1]))){
    phi1[data1[,1]==unique(data1[,1])[i],]<-t(as.matrix(list$eigenfunctions[,data1[data1[,1]==unique(data1[,1])[i],3]*l+1]))
  }
  phi2 <- matrix(rep(0,p*dim(data2)[1]),dim(data2)[1],p)
  for(i in 1:length(unique(data2[,1]))){
    phi2[data2[,1]==unique(data2[,1])[i],]<-t(as.matrix(list$eigenfunctions[,data2[data2[,1]==unique(data2[,1])[i],3]*l+1]))
  }
  
  U1<-matrix(rep(0,p*p),p,p)
  for(i in 1:length(unique(data1[,1]))){
    if(sum(data1[,1]==unique(data1[,1])[i])==1){U1<-U1+diag(eigenval1)%*%(phi1[data1[,1]==unique(data1[,1])[i],])%*%ginv(t(phi1[data1[,1]==unique(data1[,1])[i],])%*%diag(eigenval1)%*%(phi1[data1[,1]==unique(data1[,1])[i],])+sigma1*diag(sum(data1[,1]==unique(data1[,1])[i])))%*%t(phi1[data1[,1]==unique(data1[,1])[i],])%*%diag(eigenval1)}
    else{U1<-U1+diag(eigenval1)%*%t(phi1[data1[,1]==unique(data1[,1])[i],])%*%ginv(phi1[data1[,1]==unique(data1[,1])[i],]%*%diag(eigenval1)%*%t(phi1[data1[,1]==unique(data1[,1])[i],])+sigma1*diag(sum(data1[,1]==unique(data1[,1])[i])))%*%phi1[data1[,1]==unique(data1[,1])[i],]%*%diag(eigenval1)}
  }
  U2<-matrix(rep(0,p*p),p,p)
  for(i in 1:length(unique(data2[,1]))){
    if(sum(data2[,1]==unique(data2[,1])[i])==1){U2<-U2+diag(eigenval2)%*%(phi2[data2[,1]==unique(data2[,1])[i],])%*%ginv(t(phi2[data2[,1]==unique(data2[,1])[i],])%*%diag(eigenval2)%*%(phi2[data2[,1]==unique(data2[,1])[i],])+sigma2*diag(sum(data2[,1]==unique(data2[,1])[i])))%*%t(phi2[data2[,1]==unique(data2[,1])[i],])%*%diag(eigenval2)}
    else{U2<-U2+diag(eigenval2)%*%t(phi2[data2[,1]==unique(data2[,1])[i],])%*%ginv(phi2[data2[,1]==unique(data2[,1])[i],]%*%diag(eigenval2)%*%t(phi2[data2[,1]==unique(data2[,1])[i],])+sigma2*diag(sum(data2[,1]==unique(data2[,1])[i])))%*%phi2[data2[,1]==unique(data2[,1])[i],]%*%diag(eigenval2)}
  }
  
  U <- (U1+U2)/(n1+n2)
  
  t<-t(colMeans(fpcs1)-colMeans(fpcs2))%*%ginv(U/(n1)+U/(n2))%*%(colMeans(fpcs1)-colMeans(fpcs2))
  p_value<-pchisq(t, p, ncp = 0, lower.tail = FALSE, log.p = FALSE)
  return(list(t=t,p_value=p_value, p=p))  
}

