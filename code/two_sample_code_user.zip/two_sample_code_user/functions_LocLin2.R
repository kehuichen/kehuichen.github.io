LocLin.mean2<-function(data.list,n,nmax,grids=seq(0,1,0.002),mu1,mu2,a,b){

###formatting
 data.f<-Format.data(data.list,n,Nmax=nmax)
 Obs<-data.f[[1]]
 T<-data.f[[2]]
 N<-data.f[[3]]
 data<-TranMtoV(Obs,T,N)
 y<-data[,2]
 t<-data[,3]

###bandwidth selection
#(i) mu
 hmu.cv<-h.select(t,y,method="cv")
 #fitmu<-sm.regression(t,y,h=hmu.cv,poly.index=1,eval.points=t)$estimate 
 l <- length(grids) - 1
 #print(l)
 fitmu<-rep(0,length(y))
 for(k in 1:a){
  fitmu[data[,1]==k]<-mu1[data[data[,1]==k,3]*l+1]
 }
 for(k in (a+1):(a+b)){
  fitmu[data[,1]==k]<-mu2[data[data[,1]==k,3]*l+1]
 }
 fitmu.s<-sm.regression(t,y,h=hmu.cv,poly.index=1,eval.points=grids,display='none')$estimate 

##subtract mean 
 data.s<-data
 data.s[,2]<-data[,2]-fitmu  

##write back
 data.result<-data.list 
 for(i in 1:n){
  data.c<-matrix(data.s[data.s[,1]==i,],ncol=3)
  data.result[[i]][[1]]<-data.c[,2:3]
 }

 return(list(data.result,fitmu.s))
}
