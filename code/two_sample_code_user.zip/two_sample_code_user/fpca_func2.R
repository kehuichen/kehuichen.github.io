
fpca.mle2<-function(data.m, M.set,r.set,ini.method="EM", basis.method="bs",sl.v=rep(0.5,10),max.step=50,
grid.l=seq(0,1,0.01),grids=seq(0,1,0.002),mu1,mu2,a,b){
##para:data.m: the data matrix with three columns: column 1: subject ID, column 2: observation, column 3: measurement time
##M.set--# of basis functions; r.set: dimension of the process
##ini.method: initial method for Newton, one of "EM","loc"; 
##basis.method: basis functions to use for Newton, one of "bs" (cubic Bsplines), "ns" (nature splines)
##sl.v: shrinkage steps for Newton, e.g., sl.v<-c(0.5,0.5,0.5) means the first three steps are 0.5
##max.step: max number of iterations of Newton
##grid.l: grids for loc; grids: denser grids for EM/Newton;
##return: a list of (i) the selected model; (ii) the corresponding eigenfunctions; (iii)eigenvalues
##        (iv) error variance; (v) fitted mean (by local linear); (vi) the grid where the evaluation takes place

##(i)set some parameters in fpca.fit
tol<-1e-3                                        #tolerance level to determine convergence in Newton 
cond.tol<-1e+10                                  #tolerance to determine singularity in Newton 
if(length(sl.v)<max.step){
sl.v<-c(sl.v,rep(1,max.step-length(sl.v)))
}else{
sl.v<-sl.v[1:max.step]
}

if(basis.method=="bs"){
basis.method<-"poly"
}

M.self<-20
basis.EM<-"poly"                                  ##basis for EM

if(ini.method=="EM"){
no.EM<-FALSE
}else{
no.EM<-TRUE
}

iter.EM.num<-50                                   ##maximum number of iterations of EM 
sig.EM<-1                                         ##initial value of sig in EM 


nmax<-max(table(data.m[,1]))   ##maximum number of measurements per subject  
L1<-min(as.numeric(data.m[,3]))              ##range of the time 
L2<-max(as.numeric(data.m[,3]))

##(ii) format to data.list
data.list<-fpca.format(data.m)
n<-length(data.list)    ##number of subjects
 if(n==0){ 
 print("error: no subject has more than one measurements!")
 return(0)
 }

##(iii)rescale time onto [0,1]
  data.list.new<-data.list
  for (i in 1:n){
  cur<-data.list[[i]][[1]]
  temp<-(cur[,2]-L1)/(L2-L1)
  temp[temp<0.00001]<-0.00001
  temp[temp>0.99999]<-0.99999 
  cur[,2]<-temp
  data.list.new[[i]][[1]]<-cur
  }
  
 ## (iv)estimate mean and substract
  #library(sm) 
  temp<-LocLin.mean2(data.list.new,n,nmax, grids,mu1,mu2,a,b)  ##subtract estimated mean
  data.list.new<-temp[[1]]
  fitmu<-temp[[2]]

 ## (v)apply fpca.fit on all combinations of M and r in M.set and r.set and rescale back
  result<-NULL
  
  for (k in 1:length(r.set)){
  r.c<-r.set[k]
  #print(paste("r=",r.c))
  result.c<-fpca.fit(M.set,r.c,data.list.new,n,nmax,grid.l,grids,iter.EM.num,sig.EM,ini.method,basis.method,
  sl.v,max.step,tol,cond.tol,M.self,no.EM,basis.EM)
                     
   if(is.vector(result.c[[1]])){
    print("warning: see warning code")
    } 

  ##rescale back
  grids.new<-grids*(L2-L1)+L1
  
  temp<-result.c$eigenvec
  M.set.u<-M.set[M.set>=r.c]   ##only when M>=r, there is a result
  if(length(M.set.u)==0){
  temp<-NULL
  }else{
  for(j in 1:length(M.set.u)){   
  temp[[j]]<-temp[[j]]/sqrt(L2-L1)
   }
  }
  
  result.c$eigenvec<-temp
  result.c$eigenval<-result.c$eigenval*(L2-L1)
  result.c$grids<-grids.new  

  result[[k]]<-result.c
  }  
  
  ##(vi) model selection
  mod.sele<-fpca.cv(result,M.set,r.set,tol=tol)
  temp<-mod.sele[[3]]
  index.r<-temp[1] 
  index.M<-temp[2]
  cv.result<-mod.sele[[1]]
  con.result<-mod.sele[[2]]
   
  ##(vii) return the selected model
  result.sele<-result[[index.r]]
  eigenf<-result.sele$eigenvec
  eigenf.sele<-eigenf[[index.M]][,,1]
  
  eigenv<-result.sele$eigenval
  eigenv.sele<-eigenv[1,,index.M]
  
  sig<-result.sele$sig
  sig.sele<-sig[1,index.M]
  
  temp.model<-c(M.set[index.M],r.set[index.r])
  names(temp.model)<-c("M","r")
  rownames(eigenf.sele)<-paste("eigenfunction",1:r.set[index.r])
  names(eigenv.sele)<-paste("eigenvalue",1:r.set[index.r])
  temp<-list("selected_model"=temp.model,"eigenfunctions"=eigenf.sele,"eigenvalues"=eigenv.sele,"error_var"=sig.sele^2,"fitted_mean"=fitmu,"grid"=grids.new,"cv_scores"=cv.result,"converge"=con.result)
 
 return(temp)  
}


