library(TauStar) #tStar
library(MASS) #mvrnorm
library(logitnorm) #invlogit

# The example code of the test of independence based on IPR-taustar
# Choose between 1 and 2 for input data
# The code works for random vectors or random objects with distance matrices.  

# Reference: Interpoint-Ranking Sign Covariance
#            by Haeun Moon and Kehui Chen
# Written on 2021/01/26


# 1. Use sample data (Dx, Dy) 
load(file = "sampledata.rda") 

# 2. generate data
ns=100
dim=5
rho=0.1 

mu1=matrix(0, ncol=dim)
s1=matrix(c(1,rep(c(rep(rho,dim),1),dim-1)), dim, dim) 
mvn <- mvrnorm(n=ns, mu=mu1, Sigma=s1)

x<- invlogit(mvn)*2-1
y<- (round(runif(1))*2-1)*(1-abs(x))

Dx = as.matrix(dist(x), diag = TRUE, upper = TRUE)
Dy = as.matrix(dist(y), diag = TRUE, upper = TRUE)

# Test of independence using IPR-taustar
alpha=0.05
decision=(permutefun(Dx,Dy,distance="TRUE",n.perm=999)<= alpha)

