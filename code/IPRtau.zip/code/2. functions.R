library(TauStar)

# Main functions for the test of independence based on IPR-taustar
# getTauAcc returns the empirical IPR-taustar and permutefun returns a permutation p-value.

# Reference: Interpoint-Ranking Sign Covariance
#            by Haeun Moon and Kehui Chen
# Written on 2021/01/26


getTauAcc=function(x,y, distance="FALSE"){
  # compute the empirical IPR-taustar
  # Inputs: random vectors or distance matrices
  # Output : n times empirical IPR-taustar
  
  if(distance=="TRUE"){
    if(nrow(x)!=nrow(y)){	
      cat("Sample numbers is not matched.\n")
      return(0)
    }
    num =nrow(x)
    Ts <- rep(NA, length(num))
    
    for(s in 1:num){
      Ts[s]=tStar(x[s,-s], y[s,-s])
    }
  }
  
  else{
    x=as.matrix(x)
    y=as.matrix(y)
    
    if(nrow(x)!=nrow(y)){	
      cat("Sample numbers is not matched.\n")
      return(0)
    }
    num =nrow(x)
    
    #distance
    xunik=as.matrix(dist(x, method = "euclidean", diag = TRUE, upper = TRUE, p=ncol(x)))
    yunik=as.matrix(dist(y, method = "euclidean", diag = TRUE, upper = TRUE, p=ncol(y)))
    
    Ts <- rep(NA, length(num))
    
    for(s in 1:num){
      Ts[s]=tStar(xunik[s,-s], yunik[s,-s])
    }
  }
  
  return(sum(Ts))
  
}

permutefun=function(x,y,distance="FALSE",n.perm=1000){
  # Compute the permutation p-value of the empirical IPR-taustar
  # Inputs: random vectors or distance matrices
  # Output : the permutation p-value

  if(distance=="TRUE"){
    permute.N=c()
    
    TauStat<-getTauAcc(x, y, distance="TRUE")
    
    for (s in 1:n.perm-1)
    {    
      temp=sample(nrow(y),nrow(y),replace=F)
      permute.N[s] <-getTauAcc(x, y[temp,temp], distance="TRUE")
    }
    
    permute.N[n.perm]=TauStat
    
  }
  
  else{ 
    x=as.matrix(x)
    y=as.matrix(y)
    
    TauStat<-getTauAcc(x, y)
    permute.N <-c(replicate(n.perm-1, getTauAcc(x, y[sample(nrow(y),nrow(y),replace=F),])),TauStat)
    
  }
  
  p.value<-mean(permute.N>=TauStat)
  
  return(p.value)
}
