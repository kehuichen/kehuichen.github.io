# To use the following code, please first install the tPACE package available at https://github.com/hadjipantelis/tPACE

# MarginalFPCA
      source('MarginalFPCA.R')
      load('X_age_year_simu.RData')
	  #   If the data is provided in txt format, use the following 
      #	  X.age.year = read.table('X_age_year_simu.txt', header = FALSE)
 			n = dim(X.age.year)[1]
 			num.years = 56
 			num.ages = 44
      pc.j = 4
      pc.k = 4
			fpca.op1 = list(dataType = "Dense", numComponents = pc.j)
			fpca.op2 = list(dataType = "Dense", numComponents = pc.k)
      res <- MarginalFPCA(X.age.year, n, num.years, num.ages, fpca.op1, fpca.op2, pc.j, rep(pc.k, pc.j))
   
 
# ProductFPCA
      source('ProductFPCA.R')
      load('X_age_year_simu.RData')
      n = dim(X.age.year)[1]
      num.years = 56
      num.ages = 44
      pc.j = 4
      pc.k = 4
			fpca.op1 = list(dataType = "Dense", numComponents = pc.j)
			fpca.op2 = list(dataType = "Dense", numComponents = pc.k)
      res <- ProductFPCA(X.age.year, n, num.years, num.ages, fpca.op1, fpca.op2, pc.j, pc.k)
		  
			
# 2d FPCA
     load('X_age_year_simu.RData')
     n = dim(X.age.year)[1]
     num.years = 56
     num.ages = 44
		 fpca.op = list(dataType = "Dense")
		 if (sum(is.na(X.age.year)) == 0){
			 tList <- lapply(1:n, function(x) 1:(num.ages*num.years))
			 yList <- lapply(1:n, function(x) X.age.year[x,])
	   } else {
			 fpca.op$dataType = 'DenseWithMV'
			 tList <- vector('list', length  = n)
			 yList <- vector('list', length = n)
			 tvec <- 1:(num.ages*num.years)
	  	 for (i in 1:n){
	  		 ind <- which(!is.na(X.age.year[i,]))
				 yList[[i]] <- X.age.year[i,ind]
				 tList[[i]] <- tvec[ind]
	  	 }
	  }
		 
		 out.res <- FPCA(yList, tList, fpca.op)
		 eig.Age.Year <- out.res$phi[1:4]
     
     mean.X = apply(X.age.year, 2, mean, na.rm = TRUE)
     mean.Xmat = matrix(rep(mean.X,n), nrow = n, ncol = num.years*num.ages, byrow = TRUE)    
     X.age.year.c = X.age.year-mean.Xmat
     df.eig.Age.Year <- as.data.frame(eig.Age.Year)
     r <- dim(df.eig.Age.Year)[2]
     mFPCA.Age.Year.pctvar <- numeric(r)
     for (i in 1:r){
       mFPCA.Age.Year.pctvar[i] <- 
         round(mFPCA.lm(t(X.age.year.c),df.eig.Age.Year,model=i,ploting=F)$perct.model,2)
     }