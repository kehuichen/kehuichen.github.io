1. This package contains functions to perform the 
   marginal FPCA and product FPCA as proposed in 
	 `Modeling Function-Valued Stochastic Processes, With Applications to Fertility Dynamics'
    by Kehui Chen, Pedro Delicado and Hans-Georg M\"{u}ller
2. Sample code and simulated sample data are included.
3. This code depends on the tPACE package available at 
https://github.com/hadjipantelis/tPACE
4. Authors can be reached at 
   khchen@pitt.edu
   and the following website might contain updates    http://www.stat.pitt.edu/khchen/ 
