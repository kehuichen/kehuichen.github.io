function [rho_1] =SplitRho1(X, op)
% for centered X
n = size(X,1);
nsplit  = floor(n/op.nfold);

Vsplit = 0;
i1 = 0;
    
for i = 1:length(op.rho1Seq)
    rho1 = op.rho1Seq(i);
    V = 0;
    for ifold = 1:op.nfold 
        idtest = ((ifold-1)*nsplit+1):(ifold*nsplit);
        Xtrain = X(setdiff(1:n, idtest),:);
        Xtest = X(idtest,:);       
        [xcov1] = EmpiricalS(Xtrain);
        [Xcov2] = EmpiricalS(Xtest);           
        Strain = xcov1 - rho1*op.SmoothD;
        Stest = Xcov2;
        projH = seqADMM(Strain, 1, op.PrevPi, op.PrevPi_d, 0, op.maxiter, op.eps, op.verbose);
        V = V+ sum(sum(projH.*Stest));      
    end
    if (V >= Vsplit)
        Vsplit = V;
        i1 = i;
    end
end
%choose one more 
if (i1< length(op.rho1Seq))
    rho_1 = op.rho1Seq(i1+1);
else
    rho_1 = op.rho1Seq(i1);
end

end