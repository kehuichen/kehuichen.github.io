function [newvalue ] = SoftThreshold(x, lambda)
newvalue = sign(x).*max(abs(x)-lambda, 0);
end

