1. This package performs localized functional principal component analysis, 
   which can output the estimated localized eigenfunctions (basis functions), FPC scores, predicted curves, and more. 
  The main function is LFPCA(), please see detailed explanations in the file LFPCA.m
2. Please cite: Localized Functional Principal Component Analysis (2015), 
                by Kehui Chen and Jing Lei, Journal of American Statistical Association.
