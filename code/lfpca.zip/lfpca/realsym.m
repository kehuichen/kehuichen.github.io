function [ B ] = realsym(A)

B = real((A+A')/2);
end

