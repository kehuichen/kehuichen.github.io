function [rho2seq] = GenerateRho1(S, nsol, minv, maxv, skew)
 p = size(S,1);
 if (isempty(minv))
     minv = 0;
 end
 if(isempty(maxv))
     opts.disp = 0;
     l1 = eigs(realsym(S), 1, 'lA', opts);
     maxv = l1*p;
 end
 if (isempty(skew))
     skew = 1;
 end
 step = 1/(nsol-1);
 lx = (1 - exp(skew*(0:step:1)))/(1 - exp(skew));
 rho2seq = (1-lx)* minv + lx * maxv;
   
end

