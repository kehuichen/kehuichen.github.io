function [rho2seq] = GenerateRho2(S, nsol, minv, maxv, skew)
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here

 if (isempty(minv))
     minv = 0;
 end
 if(isempty(maxv))
     p = size(S,1);
     v = abs(S)+diag(NaN(1,p));
%      Smax = max(v);     
%      Smax = unique(Smax);
%      [a, Sorder] = sort(Smax, 'descend');
%      maxv = a(1);
     maxv = quantile(reshape(v, p^2, 1), 0.95);
 end
 if (isempty(skew))
     skew = 1;
 end
 step = 1/(nsol-1);
 lx = (1 - exp(skew*(0:step:1)))/(1 - exp(skew));
 rho2seq = (1-lx)* minv + lx * maxv;
   
end

