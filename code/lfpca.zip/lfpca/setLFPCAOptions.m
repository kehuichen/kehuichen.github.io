%[param] = setLFPCAOptions(varargin)
% This function sets the optional input arguments for the function LFPCA().
% =====
% Input: 
% =====
%
% This function allows 3 different ways for input:
% 
% 1)   If no input argument is provided, use default values:
%      ex: 
%      >> p = setOptions() 
%
% 2)   Provide the  name of the argument following by the value to be assign
%      to this argument. The order of the input argument pairs (argument name, value)
%      does not have to follow the same order of the input order like those defined
%      in LFPCA() or showOptionsNames(). Any undefined input arguments will be followed
%      the same as the default ones.
%
%      ex: 
%      >> showOptionNames()   %see what argument names you can define
%                            %and their orders 
%      >> p = setOptions('k',2);
% 
% 3)   Provide the argument value directly, but ORDER matters. 
%
%      >> Any undefined argument values will be set to the default ones.
%   
%       
% ======
% Output: a struct array that contains all user-defined options for LFPCA().
% ======
% 
function [param] = setLFPCAOptions(varargin)

        %set default options
       
         % sequential: 1 is estimating localized eigenfunctions one by one,
        %             0 is estimating k-dim eigenspace with localized
        %             domain. Default is 1.
        
        % k: the number of eigenfunctions to use, Default is FVE method.
        % FVE_threshold: Default is 0.85
        % FVE_M: the number of components used to compute totV. Default is 20
        % rho_1: the smoothing parameter, a positive number. Default is to use nfold cv
        % rho1Seq: the candidate set for rho_1, if nfold cv is used. 
        % rho_2: the localizing parameter, a $k$ vector or a scalar (if k is unknown).
        %        Default is to choose the biggest one that retains a proportion
        %        of variance explained, see `rho2proportion'.
        % rho2Seq: the candidate set for rho_2, if sequential == 1 and k is provided,
        %          rho2Seq (if not empty) is a cell(1,k) and rho2Seq{1} is a vector of 
        %          length nsol, otherwise rho2Seq is a vector of length nsol.
        % rho2proportion: a number between 0 and 1, corresponding to 1-a in
        %                 the paper. If not specified, will use nfold cv to
        %                 choose rho2.
        
        
        param = struct('sequential',1, 'k',[], 'FVE_threshold', 0.85, 'FVE_M', 20, ...
                   'rho_1', [], 'rho1Seq', [], 'SmoothD','2Diff',...
	               'rho_2', [], 'rho2Seq', [], 'rho2proportion', [], ...
                   'nfold', 5, 'PrevPi',[],'PrevPi_d',[],...
	               'nsol', 10, 'maxiter',100,'eps', 1e-2, 'verbose', 'off');
               
        if nargin > 0
            op_names = showOptionNames();
            paramLen = length(struct2cell(param)); 
            if ischar(varargin{1})  %match and set arguments by names
                if nargin > 2*paramLen
                      fprintf(1,'Warning: Too many input arguments!Reset to default values!\n');     
                elseif mod(nargin, 2) == 0
                      for i = 1:2:nargin
	                     id = strmatch(varargin{i},op_names,'exact');
                         if isempty(id)
                           fprintf(1,['Warning: "' varargin{i} '" is an invalid name and it will be ignored!Type showOptionNames() for more details.\n']);
                         else
		                   param = setVal(param, op_names{id}, varargin{i+1});   
                         end
                      end
                else
		           fprintf(1,'Warning:Either option name or its corresponding value is missing!Reset to default values!\n');
                end
	        else  %set arguments directly
               if nargin <= paramLen
	               
                    for i = 1:nargin
	                  param = setVal(param, op_names{i}, varargin{i});
                    end
               else
	               fprintf(1,'Warning: Too many input arguments!Reset to default values!\n');
               end      
           end

        end

end
