function [rho_2] = SplitRho2(x_c, k, PrevPi, PrevPi_d, rho2seq, op)
% for centered X

nrho2 = length(rho2seq);
Vsplit = zeros(nrho2, 1);
n = size(x_c,1);
p = size(x_c,2);
nsplit = floor(n/op.nfold);

if strcmp(op.SmoothD,'2Diff')
    op.SmoothD = getSmoothD(p);
end

nfold = op.nfold;

for i = 1: nrho2
    rho2 = rho2seq(i);
    V = 0;
    for ifold = 1:nfold
        idtest = ((ifold-1)*nsplit+1):(ifold*nsplit);
        Xtrain = x_c(setdiff(1:n, idtest),:);
        Xtest = x_c(idtest,:);
        [Xcov1] = EmpiricalS(Xtrain);
        [Xcov2] = EmpiricalS(Xtest);
        Strain = Xcov1 - op.rho_1*op.SmoothD;
        Stest = Xcov2;
        projH = seqADMM(Strain, k, PrevPi, PrevPi_d, rho2, op.maxiter, op.eps, op.verbose);       
        V = V + sum(sum(projH.*Stest)); 
    end
    Vsplit(i) = V/nfold;
end
[vmax, I] = max(Vsplit);
rho_2 = rho2seq(I);



