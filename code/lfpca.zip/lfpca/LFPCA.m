% function [res] = LFPCA(x, t_x, xcov, option)
% This is the main function for localized FPCA analysis. 
% Reference: Localized functional principal component analysis by Kehui Chen and Jing Lei
% This code only works for dense regular data. 
% The method developed in the paper could work for more flexible designs
% with a modified version of this code.

%Input: 
% x: n times p data matrix.
% t_x: the corresponding time points where x are observed.
% xcov: the covariance matrix, if [], a sample covariance will be used.
% option: the choices of tuning parameters etc, 
%         see setLFPCAOptions() and showOptionNames().

% Output: 
% res:  a struct that contains all the output. 
%       Use names(res) to see a list of output names, and use getVal() to
%       extract values. example: getVal(res, 'phi') returns the localized
%       eigenfunctions.


function [res] = LFPCA(x, t_x, xcov, option)

n = size(x,1);
p = size(x,2);

if strcmp(option.SmoothD,'2Diff')
    option.SmoothD = getSmoothD(p);
end
    opts.disp = 0;
    
xmu = mean(x,1);
x_c = x-repmat(xmu,n,1); % center data
if (isempty(xcov))
    xcov = EmpiricalS(x_c);
end 

% Use v-fold to choose rho_1, for rho_2 = 0 and k = 1
if (isempty(option.rho_1))
    if (isempty(option.rho1Seq))
        option.rho1Seq = GenerateRho1(xcov, option.nsol, [], [], []);
    end
    option.rho_1 = SplitRho1(x_c, option);
end


 S = xcov - option.rho_1*option.SmoothD;

 option.FVE_M = min(option.FVE_M, p-2);
 d = eigs(realsym(xcov),option.FVE_M, 'LA', opts);  
 d = real(d);                                
 totV = sum(d);

switch option.sequential
    case 0  
        if (isempty(option.rho_2))
            if (isempty(option.rho2Seq))
                option.rho2Seq = GenerateRho2(xcov, option.nsol, [],[],[]);
            end
            rho2seqnow = option.rho2Seq;
            if (~isempty(option.rho2proportion))
            % choose rho_2 by blancing FVE
                if (rho2seqnow(1) > 0)
                    rho2seqnow = [0, rho2seqnow];
                end
                option.rho_2 = ProportionRho2(S, xcov, option.k,  option.PrevPi, option.PrevPi_d, rho2seqnow, option, totV);
            else
            % use v-fold to choose rho_2, for fixed rho_1.
                option.rho_2 = SplitRho2(x_c, option.k, option.PrevPi, option.PrevPi_d, rho2seqnow, option);
            end
        end      
        projH = seqADMM(S, option.k, option.PrevPi, option.PrevPi_d, option.rho_2, option.maxiter, option.eps, option.verbose);
        %Post-process the estimated projection
        [vec,D]= eigs(realsym(projH), option.k, 'LA', opts);
        % Rotate the basis vectors so that the 
        % projected sample covariance matrix is diagonal
        [S0.vec, D] = eigs(realsym(vec'*S*vec), option.k, 'LA', opts);
        eigV = vec*S0.vec;
        FVE = sum(diag(eigV'*xcov*eigV))/totV;
        k = option.k;
    case 1
        vec  = zeros(p,p);
        rho_2 = zeros(1, p);
        FVE = zeros(1, p);
        PrevPi = [];
        ki = 0;
        cont = 1;
        rho2seq = cell(1,p);
        while (cont && ki< option.FVE_M)
            ki = ki+1;
            if (~isempty(option.rho_2))
                if (~isempty(option.k))           
                    rho_2(ki) = option.rho_2(ki);
                else
                    rho_2(ki) = option.rho_2;
                end
            else 
                if (isempty(option.rho2Seq))
                    xcovnow = deflate(xcov, PrevPi);
                    rho2seq{ki} = GenerateRho2(xcovnow, option.nsol, [],[],[]);
                elseif (~isempty(option.k))
                    rho2seq{ki} = option.rho2Seq{ki};
                else
                    rho2seq{ki} = option.rho2Seq;
                end
                rho2seqnow = rho2seq{ki};
                if (~isempty(option.rho2proportion))
                % choose rho_2 by blancing FVE
                    if (rho2seqnow(1) > 0)
                        rho2seqnow = [0, rho2seqnow];
                    end
                    rho_2(ki) = ProportionRho2(S, xcov, 1, PrevPi, (ki-1), rho2seqnow, option, totV);
                else  %use v-fold to choose rho_2, for fixed rho_1              
                    rho_2(ki) = SplitRho2(x_c, 1, PrevPi, (ki-1), rho2seqnow, option);
                end
            end
            
            projH = seqADMM(S, 1, PrevPi, (ki-1), rho_2(ki), option.maxiter, option.eps, option.verbose);
            [vec(:,ki),D]= eigs(realsym(projH), 1, 'LA', opts);
            FVE(ki) = sum(diag(vec(:,ki)'*xcov*vec(:,ki)))/totV;
            if (isempty(option.k))  %choose k by FVE
                FVE0 = sum(FVE(1:ki));
                if (FVE0 > option.FVE_threshold)
                    cont = 0;
                end
            elseif (ki == option.k)
                cont = 0;
            end
            PrevPi = vec(:,1:ki)*(vec(:,1:ki)');
        end
        k = ki;   
        eigV = vec(:,1:k);
        projH = eigV*eigV';
        option.rho_2 = rho_2(1:k);
        FVE = FVE(1:k);
        option.rho2Seq = rho2seq(1:k);
        option.k = k;
end
h = range(t_x)/(p-1);
phi = (eigV/sqrt(h));
% for i = 1:k  %further normlize
%     phi(:,i) = phi(:,i)/sqrt(trapz(T,phi(:,i).^2));    
% end
xi_est = zeros(n, k);
for i = 1: k
    prod =x_c.*repmat(phi(:,i)', n,1);
    xi_est(:,i) = trapz(t_x,prod,2);
end
predx = repmat(xmu, n, 1) + xi_est*phi';
Xnames = {'predx', 'xi_est', 'phi',  'FVE', 'totV', 'projH','eigV','option', 'names'};
res = { predx, xi_est, phi,  FVE, totV, projH, eigV, option, Xnames};
end

