%[op_names] = showOptionNames()
%This function display the optional input argument names for LFPCA.
%It will be helpful if you want to use setOptions() to set the values
%corresponding to these names.
function [op_names] = showOptionNames()
     op_names = {'sequential', 'k','FVE_threshold', 'FVE_M', ...
                'rho_1', 'rho1Seq', 'SmoothD', 'rho_2','rho2Seq', 'rho2proportion', 'nfold','PrevPi','PrevPi_d',...
                'nsol', 'maxiter','eps','verbose'};
end
