function [rho_2] = ProportionRho2(S, xcov, k, PrevPi, PrevPi_d, rho2seq, op, totV)
% for centered X
nrho2 = length(rho2seq);
FVE = zeros(nrho2, 1);
opts.disp = 0;
for i = 1: nrho2 
    rho2 = rho2seq(i);
    projH = seqADMM(S, k, PrevPi, PrevPi_d, rho2, op.maxiter, op.eps, op.verbose); 
    if (op.sequential == 0)
        [vec, D]= eigs(realsym(projH), k, 'LA', opts);
        [S0.vec, D] = eigs(realsym(vec'*S*vec), op.k, 'LA', opts);
        eigV = vec*S0.vec;
    else        
        [eigV, D]= eigs(realsym(projH), 1, 'lA', opts);
    end
    FVE(i) = sum(diag(eigV'*xcov*eigV))/totV;
end
prop = FVE/FVE(1); 
I = find(prop >= op.rho2proportion, 1, 'last');
rho_2 = rho2seq(I);



