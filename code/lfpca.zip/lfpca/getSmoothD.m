function [ D ] = getSmoothD(p)
Delta = zeros(p-2, p);
for i = 1:(p-2)
    Delta(i,i) = 0.5;
    Delta(i,i+2) = 0.5;
    Delta(i,i+1) = -1;
end
D = Delta'*Delta;
end

