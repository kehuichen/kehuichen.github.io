function [newmat] = FantopeProj(mat,mat0,d, ndim)
if (~isempty(mat0))
    p = size(mat0,1);
    [U, D] = eig(diag(ones(1,p))-mat0);
    [a,id] = sort(diag(D), 'descend');
    U = U(:,id);
    U = U(:,1:(p-d));
    mat = U'*mat*U;
end
mat = real((mat'+mat)/2);
[V, D] = eig(mat);
D = diag(D);
[a, id] = sort(D, 'descend');
V = V(:,id);
D = D(id);
theta = GetTheta(D, ndim);
new.values = min(max(D-theta, 0),1);
newmat = V*diag(new.values)*V';
if (~isempty(mat0))
    newmat = U*newmat*U';
end
end

