function [projH] = seqADMM(S, ndim, PrevPi, PrevPi_d, rho_2, maxiter, eps, verbose)
% direct eigen decomposition

p = size(S,1);
if (rho_2 == 0)
    S = deflate(S, PrevPi);
    opts.disp = 0;
    [V, D]= eigs(realsym(S), ndim, 'LA', opts);
    projH = V*V';
else
    %eps = ndim*(eps*median(max(abs(S))))^2;
    
    eps = ndim*eps;
    tau = 0.1 * max(max(abs(S))); %search step size
    tauStep = 2;
    
    y0 = zeros(p,p);
    w0 = zeros(p,p);
    
    niter = 0;
    maxnorm = eps+1;
    while((niter < maxiter) && (maxnorm > eps))
        % update h
        h = FantopeProj(y0-w0+S/tau, PrevPi,PrevPi_d, ndim);
        % update y
        y1 = SoftThreshold(h + w0,rho_2/tau);
        % update w
        w1 = w0 + h - y1;
        % stop criterion
        normr1 = (norm(h-y1, 'fro'))^2;
        norms1 = (norm(tau*(y0-y1), 'fro'))^2;
        maxnorm = max(normr1, norms1);
        niter = niter+1;
        % update
        y0 = y1;
        if(normr1>100*norms1)
            tau = tau*tauStep;
            w0 = w1/tauStep;
        else
            if (norms1>100*normr1)
                tau = tau/tauStep;
                w0 = w1*tauStep;
            else
                w0 = w1;
            end
        end
        
    end
    
    if strcmp(verbose, 'on') == 1
        if(niter< maxiter)
            fprintf(1, ['seqADMM has converged after ', num2str(niter), ' iterations\n'])
        else
            fprintf(1,'seqADMM could not converge\n')
        end
    end
    projH = y1;
end

