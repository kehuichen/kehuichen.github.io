function [S] = deflate(S, PrevPi)
if (~isempty(PrevPi))
    p = size(S,1);
    I = eye(p);
    S = (I-PrevPi)*S*(I-PrevPi);
    %S = S- PrevPi*S*PrevPi;
end
end

