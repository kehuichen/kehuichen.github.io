function [xcov] = EmpiricalS(X)
% X need to be centered
 n = size(X,1);
 xcov = X'*X/n;
end

