source('NCV_utils.R')

n <- 1000
type <- 'SBM'
K <- 2
k.candidate <- 1:6
nfold <- 3
r <- 0.1
B0 <- matrix(1,K,K) + diag(2, K)
B <- r*B0 

# generate data
clust.size <- rep(n/K, K)
Theta <- Generate.theta(n, K, clust.size)
phat <- Theta%*%B%*%t(Theta)
A <- Generate.A(phat)

## model selection

# ncv with spectral method, ncv.spec
res <-CVBOTH.Rec(A, K.vec = k.candidate, n.fold = nfold, type = type)
k.chosen <- res$k.chosen


# ncv with least square method
res <-CV.LS.1(A, K.vec = k.candidate, n.fold = nfold)
k.chosen <- res$k.chosen


# ncv with spectral method and 20 repetitions
n.dup <- 20
kchosen <- rep(0,n.dup)
for (dupi in 1:n.dup){
   res <-CVBOTH.Rec(A, K.vec = k.candidate, n.fold = nfold, type = type)
	 kchosen[dupi] <- res$k.chosen
}
a <- table(kchosen)
ka <- as.numeric(names(a))
k.chosen <- ka[which.max(a)]     


# ncv with least sequare method and 20 repetitions
n.dup <- 20
kchosen <- rep(0,n.dup)
for (dupi in 1:n.dup){
	 	res <-CV.LS.1(A, K.vec = k.candidate, n.fold = nfold)
	  kchosen[dupi] <- res$k.chosen
}
a <- table(kchosen)
ka <- as.numeric(names(a))
k.chosen[ <- ka[which.max(a)]	 



# choose between DCBM and SBM, spectral method
DCBM <- TRUE
type <- 'both'
# generate data from DCBM 
clust.size <- rep(n/K, K)
psi <- Generate.psi(n, K, clust.size, DCBM)
theta <- Generate.theta(n, K, clust.size)
Theta <- diag(psi) %*% theta
A <- Generate.A(Theta%*%B%*%t(Theta))
res <- CVBOTH.Rec(A, K.vec = k.candidate, n.fold = nfold, type = type)
k.chosen <-res$k.chosen
model.chosen <- res$model

    


