### Main functions ##########
CVBOTH.Rec <- function(A, K.vec = 1:6, n.fold = 3, n.dim = NULL, type = c('SBM','both','DCBM'), method = c('likelihood', 'ls')) {
  ## Cross validation for choosing number of clusters in SBM, using spectral method for community detection
  # Input: 
  # A: adjacency matrix
  # K.vec: the candidate values for K
  # n.fold: the cross-validation fold
  # n.dim: the number of eigenvectors used for clustering.
  # type: could be one of 'SBM', 'DCBM' or 'both'. Use 'SBM' or 'DCBM' if only to choose k. Use 'both' if want to simultaneously choose k and choose between SBM vs DCBM.
  
  # Output:
  # a list contains the selected model, the selected k, and the value of the criterion function for each model. 
  type = type[1]
  method = method[1]
  n <- nrow(A)
  sample.ind <- sample.int(n)
  fold.size <- floor(n / n.fold)
  fold.ind <- list()
  for (i in 1:(n.fold - 1)) {
    fold.ind[[i]] <- sort(sample.ind[((i-1)*fold.size+1):(i*fold.size)])
  }
  fold.ind[[n.fold]] <- sort(sample.ind[((n.fold - 1) * fold.size + 1) : n])

  n.K <- length(K.vec)
  error.mat.sbm<- matrix(0, nrow = n.fold, ncol = n.K)
  error.mat.dcbm <- matrix(0, nrow = n.fold, ncol = n.K)

  for (i in 1:n.fold) {
    tmp.ind <- fold.ind[[i]]
    A.1 <- A[-tmp.ind, -tmp.ind]
    A.12 <- A[-tmp.ind, tmp.ind]
    A.2 <- A[tmp.ind, tmp.ind]
      
    for (j in 1:n.K) {
      K <- K.vec[j]
      n.dim.tmp <- ifelse(is.null(n.dim), K, n.dim)
      if (type == 'SBM'){
        error.mat.sbm[i,j] <- Validate.Rec(A.1, K, A.12, A.2, n.dim = n.dim.tmp, method = method)
      } 
      if (type == 'DCBM'){
        error.mat.dcbm[i,j] <- Validate.DCBM.Rec(A.1, K, A.12, A.2,
                                                n.dim = n.dim.tmp, method = method)
      }
      if (type == 'both'){
          error.mat.sbm[i,j] <- Validate.Rec(A.1, K, A.12, A.2, n.dim = n.dim.tmp, method = method)
        
          error.mat.dcbm[i,j] <- Validate.DCBM.Rec(A.1, K, A.12, A.2, n.dim = n.dim.tmp, method = method)
      }    
    }
  }
  cv.sbm = apply(error.mat.sbm, 2, mean)
  cv.dcbm = apply(error.mat.dcbm, 2, mean)
  if (type == 'SBM'){
    k.chosen <- K.vec[which.min(cv.sbm)]
    model <-'SBM'
  }
  if (type == 'DCBM'){
    k.chosen <- K.vec[which.min(cv.dcbm)]
    model <-'DCBM'
  }
  if (type == 'both'){
    k1 <- which.min(cv.sbm)
    k2 <- which.min(cv.dcbm)
    k.chosen <- K.vec[k1]
    model <- 'SBM'
    if (cv.dcbm[k2] < cv.sbm[k1]){
      k.chosen <- K.vec[k2]
      model <- 'DCBM'
    }
  }

  return(list(model = model,
              k.chosen = k.chosen,
              cv.sbm = cv.sbm,
              cv.dcbm = cv.dcbm))
}


CV.LS.1 <- function(A, K.vec = 1:6, n.fold = 3) {
  # Cross validation for choosing number of clusters in SBM using least square methods
  # A: adjacency matrix
  # K.vec: the candidate values for K
  # n.fold: the cross-validation fold
  
  n <- nrow(A)
  sample.ind <- sample.int(n)
  fold.size <- floor(n / n.fold)
  fold.ind <- list()
  for (i in 1:(n.fold - 1)) {
    fold.ind[[i]] <- sort(sample.ind[((i-1)*fold.size+1):(i*fold.size)])
  }
  fold.ind[[n.fold]] <- sort(sample.ind[((n.fold - 1) * fold.size + 1) : n])

  n.K <- length(K.vec)
  error.mat.sbm <- matrix(0, nrow = n.fold, ncol = n.K)
  for (i in 1:n.fold) {
    tmp.ind <- fold.ind[[i]]
    A.1 <- A[-tmp.ind, -tmp.ind]
    A.12 <- A[-tmp.ind, tmp.ind]
    A.2 <- A[tmp.ind, tmp.ind]
    for (j in 1:n.K) {
      K <- K.vec[j]
      validated.error.sbm <- Validate.LS.1(A.1, K, A.12, A.2)
      error.mat.sbm[i,j] <- validated.error.sbm$sq.err
    }
  }
  
  cv.sbm = apply(error.mat.sbm, 2, mean)
  k.chosen <- which.min(cv.sbm)   
  
  return(list(k.chosen = k.chosen,
              cv.sbm = cv.sbm))
}

## Other functions #########################################

SpecClust.Rec <- function(A, K, sphere = F, n.dim = K) {
  # spectral clustering on rectangular
  n <- nrow(A)
  if (K == 1) {
    return(rep(1, n))
  }
  U <- svd(A, nv = 0, nu = n.dim)$u
  #U <- slanczos(A%*%t(A), n.dim)$vectors
  #U <- propack.svd(A, n.dim)$u
  #U <- irlba(A, nu = n.dim, nv = 0)$u
  if (sphere) {
    for (i in 1:n) {
      U[i,] = U[i,] / sqrt(sum(U[i,]^2))
    }
  }
  return(kmeans(U, K, nstart = 20)$cluster)
#  return(clusters(kcca(U, K)))
}

SpecClust.DCBM.Rec <- function(A, K, n.dim = K) {
  # spectral clustering for DCBM
  n <- nrow(A)
  n.1 <- ncol(A)
  if (K == 1) {
    svd.a <- svd(A, nu = 1, nv = 1)
    U <- svd.a$u
    V <- svd.a$v
    U <- U * sign(U[1])
    V <- V * sign(V[1])
    psi.hat <- as.vector(U / max(U))
    psi.hat.1 <- as.vector(V / sqrt(sum(V^2)) * sqrt(sum(psi.hat[1:n.1]^2)))
    psi.hat.final <- c(psi.hat.1, psi.hat[(n.1+1):n])
    n.edge <- sum(A[1:n.1,]) / 2 + sum(A[(n.1+1):n,])
    sum.weight <- ((sum(psi.hat.1))^2 - sum(psi.hat.1^2)) / 2 +
                sum(psi.hat.1) * sum(psi.hat[(n.1+1):n])
    p.hat <- (n.edge + 1) / (sum.weight + 1)
    return(list(clusters = rep(1, n), 
                B = matrix(p.hat, ncol = 1, nrow = 1),
                psi.hat = psi.hat.final))
  } else {
    A.1 <- A[1:n.1,]
    A.12 <- t(A[(n.1+1):n,])
    svd.a <- svd(A+matrix(0.001, ncol = ncol(A), nrow = nrow(A)),
                 nv = n.dim, nu = n.dim)
    U <- svd.a$u
    V <- svd.a$v
    psi.hat <- rep(0,n)
    psi.1.hat <- rep(0, n.1)
    U.tilde <- U
    for (i in 1:n) {
      psi.hat[i] <- sqrt(sum(U[i,]^2))
      U.tilde[i,] <- U[i,] / psi.hat[i]
      if (i <= n.1) {psi.1.hat[i] <- sqrt(sum(V[i,]^2))}
    }
    clusters <- kmeans(U.tilde, K, nstart = 20)$cluster
    n.2 <- n - n.1
    B <- matrix(0, nrow = K, ncol = K)
    clust.ind.1 <- list()
    clust.ind.2 <- list()
    clust.ind <- list()
    clust.size.1 <- rep(0,K)
    clust.size.2 <- rep(0,K)
    psi.hat.n <- rep(0,n)
    psi.1.hat.n <- rep(0,n.1)
    for (i in 1:K) {
      clust.ind.1[[i]] <- which(clusters[1:n.1]==i)
      clust.ind.2[[i]] <- which(clusters[(n.1+1):n]==i)
      clust.ind[[i]] <- which(clusters==i)
      psi.hat.n[clust.ind[[i]]] <- psi.hat[clust.ind[[i]]] /
                                   max(psi.hat[clust.ind[[i]]])
      psi.1.hat.n[clust.ind.1[[i]]] <- psi.1.hat[clust.ind.1[[i]]] /
        sqrt(sum(psi.1.hat[clust.ind.1[[i]]]^2)) *
        sqrt(sum(psi.hat.n[clust.ind.1[[i]]]^2))
      e.tmp <- sum(A.1[clust.ind.1[[i]], clust.ind.1[[i]]]) / 2 +
               sum(A.12[clust.ind.1[[i]], clust.ind.2[[i]]])
      w.tmp <- sum(psi.1.hat.n[clust.ind.1[[i]]])^2 / 2 -
               sum(psi.1.hat.n[clust.ind.1[[i]]]^2) / 2 +
               sum(psi.1.hat.n[clust.ind.1[[i]]]) *
               sum((psi.hat.n[(n.1+1):n])[clust.ind.2[[i]]])
      B[i,i] <- (e.tmp + 1) / (w.tmp + 1)
    }
    for (i in 1:(K-1)) {
      for (j in (i+1):K) {
        e.tmp <- sum(t(A)[clust.ind.1[[i]], clust.ind[[j]]])
        w.tmp <- sum(psi.1.hat.n[clust.ind.1[[i]]]) *
                 sum(psi.hat.n[clust.ind[[j]]])
        B[i,j] <- (e.tmp + 1) / (w.tmp + 1)
        B[j,i] <- B[i,j]
      }
    }
    psi.hat.final <- c(psi.1.hat.n, psi.hat.n[(n.1+1):n])
    return(list(clusters = clusters, B = B, psi.hat = psi.hat.final))    
  }
}
EmpB.Rec <- function(A.1, A.12, clusters) {
  # empirical connectivity matrix
  n.1 <- nrow(A.12)
  n.2 <- ncol(A.12)
  n <- n.1 + n.2
  values <- sort(unique(clusters))
  K <- length(values)
  B <- matrix(0, nrow = K, ncol = K)
  clust.ind.1 <- list()
  clust.size.1 <- rep(0, K)
  clust.ind.2 <- list()
  clust.size.2 <- rep(0, K)
  for (i in 1:K) {
    clust.ind.1[[i]] <- which(clusters[1:n.1] == i)
    clust.ind.2[[i]] <- which(clusters[(n.1 + 1):n] == i)
    clust.size.1[i] <- length(clust.ind.1[[i]])
    clust.size.2[i] <- length(clust.ind.2[[i]])
  }
  for (i in 1:K) {
    e.tmp <- sum(A.1[clust.ind.1[[i]], clust.ind.1[[i]]]) / 2 +
                   sum(A.12[clust.ind.1[[i]], clust.ind.2[[i]]])
    n.tmp <- (clust.size.1[i]^2 - clust.size.1[i]) / 2 +
             clust.size.1[i] * clust.size.2[i]
    B[i,i] <- (e.tmp + 1) / (n.tmp + 1)
    if (i < K) {
      for (j in (i+1):K) {
        e.tmp <- sum(A.1[clust.ind.1[[i]], clust.ind.1[[j]]]) +
                 sum(A.12[clust.ind.1[[i]], clust.ind.2[[j]]])
        n.tmp <- clust.size.1[i] * (clust.size.1[j] + clust.size.2[j])
        B[i,j] <- (e.tmp + 1) / (n.tmp + 1)
        B[j,i] <- B[i,j]
      }
    }
  }
  return(B)
}

Validate.Rec <- function(A.1, K, A.12, A.2, n.dim = K, method = c('likelihood', 'ls')){
  # compute the edge prediction error
  # Dependency: CrossClust, SpecClust, ClustVec2Mat
  # Inputs:
  #   A.1    - training adjacency matrix
  #   K      _ number of clusters
  #   A.12   - cross adjacency matrix between training and testing
  #   A.2    - testing adjacency matrix
  #   method - likelihood or ls
  # Outputs:
  n.1 <- nrow(A.1)
  n.2 <- nrow(A.2)
  n <- n.1 + n.2
  A.rec <- cbind(A.1, A.12)
  
  if (K == 1) {
    #p <- (sum(A.1) + 2) / (n.1^2 - n.1 + 2)
    p <- (sum(A.1) / 2 + sum(A.12) + 1) / ((n.1^2 - n.1) / 2 + n.1 * n.2 + 1)
    err <- 0
    for (i in 1:(n.2 - 1)) {
      for (j in (i+1):n.2) {
        err <- switch(method, likelihood = err - A.2[i,j] * log(p) - (1 - A.2[i,j]) * log(1 - p), ls  = err + (p - A.2[i,j])^2)
      }
    }
    return(err)
  } else {
    clusters <- SpecClust.Rec(A = t(A.rec), K = K, n.dim = n.dim)
	  cluster.2 <- clusters[(n.1 + 1):n]  
    if (length(unique(cluster.2)) < K) {
      err = Inf
      return(err)
    } else { 
      err <- 0
      Theta.2 <- ClustVec2Mat(cluster.2, K)   
  	  B.rec <- EmpB.Rec(A.1, A.12, clusters)      
      P.2 <- Theta.2 %*% B.rec %*% t(Theta.2)   
      for (i in 1:(n.2 - 1)) {
        for (j in (i+1):n.2) {
          err  <- switch(method, likelihood = err - A.2[i,j] * log(P.2[i,j]) - (1 - A.2[i,j]) * log(1 - P.2[i,j]),
                        ls = err + (P.2[i,j] - A.2[i,j])^2)
        }
      }    
      return(err)
    }
  }
}

Validate.DCBM.Rec <- function(A.1, K, A.12, A.2, n.dim = K, method = c('likelihood', 'ls')) {
  # compute the edge prediction error
  # Dependency: CrossClust, SpecClust, ClustVec2Mat
  # Inputs:
  #   A.1    - training adjacency matrix
  #   K      _ number of clusters
  #   A.12   - cross adjacency matrix between training and testing
  #   A.2    - testing adjacency matrix
  
  # Outputs:

  n.1 <- nrow(A.1)
  n.2 <- nrow(A.2)
  n <- n.1 + n.2
  A.rec <- t(cbind(A.1, A.12))

  dcbm.params <- SpecClust.DCBM.Rec(A.rec, K = K, n.dim = n.dim)
  psi.hat <- dcbm.params$psi.hat
  B <- dcbm.params$B
  clusters <- dcbm.params$clusters
  clusters.2 <- clusters[(n.1 + 1):n]
  if (length(unique(clusters.2)) < K) {
    return(Inf)
  } else {
    Theta.2 <- ClustVec2Mat(clusters.2, K)
    psi.2 <- psi.hat[(n.1 + 1):n]
    P.2 <- diag(psi.2) %*% Theta.2 %*% B %*% t(Theta.2) %*% diag(psi.2)
    P.2 <- pmax(pmin(P.2, 0.999), 1e-10)
    err <- 0
    for (i in 1:(n.2 - 1)) {
      for (j in (i+1):n.2) {
        err  <-  switch(method, likelihood = err - A.2[i,j] * log(P.2[i,j]) - (1 - A.2[i,j]) * log(1 - P.2[i,j]),
                        ls = err + (P.2[i,j] - A.2[i,j])^2)
      }
    }
    return(err)
  }
}

ClustVec2Mat <- function(clust.vec, K) {
  # convert a membership vector to a membership matrix, the number of different values in
  # clust.vec must be at most K
  clust.mat <- matrix(0, ncol = K, nrow = length(clust.vec))
  for (i in 1:K) {
    clust.mat[clust.vec==i,i] <- 1
  }
  return(clust.mat)
}

ClustError <- function(T1, T2) {
  # cluster error calculation, taking into account of possibly label permutation
  # Inputs:
  #   T1 - a *vector* of estimated cluster membership
  #   T2 - the true membership *matrix*
  n <- dim(T2)[1]
  K <- dim(T2)[2]
  T1.new <- ClustVec2Mat(T1, K)
  perm.list <- permn(1:K)
  l <- length(perm.list)
  rec.err <- rep(0, l)
  for (i in 1:l) {
    rec.err[i] <- sum(sum(abs(T1.new[, perm.list[[i]] ] - T2))) / 2
  }
  i.star <- which(rec.err==min(rec.err))[1]
  return(list(clust.est = T1.new %*% diag(K)[perm.list[[i.star]],], err = rec.err[i.star]))
}




Generate.A <- function(P) {
  # generates random adjacency matrix
  n <- dim(P)[1]
  upper.tri.ind <- upper.tri(P)
  p.upper <- P[upper.tri.ind]
  A.upper <- rbinom(n*(n-1)/2, 1, p.upper)
  A <- matrix(0, ncol = n, nrow = n)
  A[upper.tri.ind] <- A.upper
  A <- A + t(A)
  return(A)
}

Generate.clust.size <- function(n, K, prob = NULL){
  if (is.null(prob)) {
    prob <- rep(1/K, K)
  }
  clust.size <- rmultinom(1, n, prob)
  return(clust.size)
}

Generate.psi <- function(n, K, clust.size, DCBM, low.limit = 0.2, upp.limit = 1){
  if (DCBM) {
    psi <- low.limit + (upp.limit-low.limit)* runif(n)
    for (k in 1:K){
      if (k==1){id1 <-1} else {id1 <- sum(clust.size[1:(k-1)])+1}
      id2 <- sum(clust.size[1:k])
      psi[id1:id2] <- psi[id1:id2] / max(psi[id1:id2])
    }
  } else {
    psi <- rep(1, n)
  }
  return(psi)
}

Generate.theta <- function(n, K, clust.size){
  theta <- matrix(0, n, K)
  for (k in 1:K){
      if (k==1){id1 <-1} else {id1 <- sum(clust.size[1:(k-1)])+1}
      id2 <- sum(clust.size[1:k])
      theta[id1:id2, k] <- 1
  } 
  return(theta)
}


GetCluster.Rec.1 <- function(A, k, reps = 3, maxit = 100, verbose ='off'){
 # by  kehui chen @khchen@pitt.edu
  # A is m * m.1, this code only works for p = 1
  totsumDBest <- Inf
  idxBest <- NULL
  centerBest <- NULL
  dimvec <- dim(A)
  m <- dimvec[1]
  m.1 <- dimvec[2]
  if (dim(unique(A))[1] <k) {
    return(list(idx = idxBest, center = centerBest))
  }
  for (rep in 1:reps){
    idx <- kmeans(A, k)$cluster 
    iter <- 0
    prevtotsumD <- Inf
    while (iter < maxit){
      if (verbose == 'on'){
         cat('step = ', iter, '\n' )
         }
      iter <- iter + 1
      # deal with cluster that have just lose all their members
      counts <- summary(factor(idx, 1:k))
      empties <- which(counts == 0)
      for (i in empties){
        from <- sample(which(counts > 1), 1,0)
        lonely <- sample(which(idx == from), 1, 0)
        idx[lonely] <- i
        counts[i] <- 1
        counts[from] <- counts[from]-1; 
      }   
      center <- GetCenter.1(A, idx, k)
      D <- GetDist.1(A, center[idx[1:m.1],])
      totsumD <- sum(D[(idx-1)*m+(1:m)])  
      if (prevtotsumD <  totsumD | prevtotsumD == totsumD){
        break    
      }
      previdx <- idx
      prevtotsumD <- totsumD
      prevcenter <- center
      nidx <- apply(D, 1, which.min)
      moved <- which(nidx != previdx)
      # resolve tie in favor of not move
      if (length(moved)>0) {
        moved <- moved[D[(previdx[moved]-1)*m+moved] > min(D[moved,])] 
      } 
      if (length(moved) ==0){
        break
      }
      idx[moved] = nidx[moved]
    }
    if (totsumD < totsumDBest){
      totsumDBest <- totsumD
      idxBest <-idx
      centerBest <- center
    }
  }
  return(list(idx = idxBest, center = centerBest))
}


Validate.LS.1 <- function(A.1, K, A.12, A.2) {
  # compute the edge prediction error
  # Dependency: 

  n.1 <- nrow(A.1)
  n.2 <- nrow(A.2)
  n <- n.1 + n.2
  A.rec <- cbind(A.1, A.12)
  
  if (K == 1) {
    p <- (sum(A.1) / 2 + sum(A.12) + 1) / ((n.1^2 - n.1) / 2 + n.1 * n.2 + 1)
    sq.err <- 0
    for (i in 1:(n.2 - 1)) {
      for (j in (i+1):n.2) {
        sq.err <- sq.err + (p - A.2[i,j])^2
      }
    }
    return(list(sq.err = sq.err))
  } else {
    clusters <- GetCluster.Rec.1(A = t(A.rec), k = K)$idx
	  cluster.2 <- clusters[(n.1 + 1):n]  
    if (length(unique(cluster.2)) < K) {
      return(list(sq.err = Inf))
    } else { 
      sq.err <- 0
      Theta.2 <- ClustVec2Mat(cluster.2, K)   
      B.rec <- EmpB.Rec(A.1, A.12, clusters)
      P.2 <- Theta.2 %*% B.rec %*% t(Theta.2)   
      for (i in 1:(n.2 - 1)) {
        for (j in (i+1):n.2) {
          sq.err <- sq.err + (P.2[i,j] - A.2[i,j])^2
        }
      }
      return(list(sq.err = sq.err, clusters = clusters, B.hat = B.rec))
    }
  }
}

GetCluster.1 <- function(A, k, reps = 3, maxit = 100, verbose ='off'){
 # by  kehui chen @khchen@pitt.edu
  # A is m * m, this code only works for p = 1
  totsumDBest <- Inf
  idxBest <- NULL
  centerBest <- NULL
  dimvec <- dim(A)
  m <- dimvec[2]
  if (dim(unique(A))[1] <k) {
    return(list(idx = idxBest, center = centerBest))
  }
  for (rep in 1:reps){
    idx <- kmeans(A, k)$cluster 
    iter <- 0
    prevtotsumD <- Inf
    while (iter < maxit){
      if (verbose == 'on'){
         cat('step = ', iter, '\n' )
         }
      iter <- iter + 1
      # deal with cluster that have just lose all their members
      counts <- summary(factor(idx, 1:k))
      empties <- which(counts == 0)
      for (i in empties){
        from <- sample(which(counts > 1), 1,0)
        lonely <- sample(which(idx == from), 1, 0)
        idx[lonely] <- i
        counts[i] <- 1
        counts[from] <- counts[from]-1; 
      }   
      center <- GetCenter.1(A, idx, k)
      D <- GetDist.1(A, center[idx,])
      totsumD <- sum(D[(idx-1)*m+(1:m)])  
      if (prevtotsumD <  totsumD | prevtotsumD == totsumD){
        break    
      }
      previdx <- idx
      prevtotsumD <- totsumD
      prevcenter <- center
      nidx <- apply(D, 1, which.min)
      moved <- which(nidx != previdx)
      # resolve tie in favor of not move
      if (length(moved)>0) {
        moved <- moved[D[(previdx[moved]-1)*m+moved] > min(D[moved,])] 
      } 
      if (length(moved) ==0){
        break
      }
      idx[moved] = nidx[moved]
    }
    if (totsumD < totsumDBest){
      totsumDBest <- totsumD
      idxBest <-idx
      centerBest <- center
    }
  }
  return(list(idx = idxBest, center = centerBest))
}

GetCenter.1 <-function(A, idx, k){
  m.1 <- dim(A)[2]
  idx.1 <- idx[1:m.1]
  center <- matrix(0, k, k)
  for (i in 1:k){
    for (j in i:k){
       if ((sum(idx == i) ==1) & (sum(idx.1==j)==1) ) {
         center[i,j] <- 0.5
         center[j,i] <- center[i,j]
       } else if (sum(idx.1 == j) == 0 ){
	     center[i,j] <- mean(A[idx==i,])
		 center[j,i] <- center[i,j]
	   } else 
	   {
       center[i,j] <- mean(A[idx==i,idx.1==j])
       center[j,i] <- center[i,j]
       }
    }
  }
  return(center)
}


GetDist.1 <- function(A, center){
  # A: m*m.1
  # center: m.1*k  
  m <- dim(A)[1]
  k <- dim(center)[2]
  if (is.null(k)) {
    k <- 1
	D <- matrix(0, m, k)
	for (j in 1:m){
       D[j] <- sum((t(A[j,]) - center)^2)
    }	
  } else { 
    D <- matrix(0, m, k)
    for (j in 1:m){
       for (i in 1:k){
        D[j,i] <- sum((t(A[j,]) - center[,i])^2)
       }
    }
  }
  return(D)
}