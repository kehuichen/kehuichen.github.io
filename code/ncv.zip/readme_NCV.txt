1. The main functions for Network CV are CVBOTH.Rec and CV.LS.1
  CVBOTH.Rec uses spectral method for community detection. It takes the adjacency matrix and output the selected model (SBM or DCBM), as well as the appropriate number of communities K. Detailed input and output explanations can be find under function CVBOTH.Rec in NCV_utils.R
  CV.LS.1 uses least square /likelihood method for community detection. It takes the adjacency matrix and output the number of communities K. The current version does not have DCBM options. 

2. Example code for model selection can be found in example.R
  

3. Reference: Chen, K. and Lei, J. (2016): Network Cross-Validation for Determining the Number of Communities in Network Data.