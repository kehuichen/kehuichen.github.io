function[xou,muv, mud, beta,iter_fbeta] = Updatef(y, Xcov,  idx, beta,center ,frac, bw,kernel, nwe, npoly,nder,linkArg,distriArg,ftype  )
% It's coded for estimating  f  and beta for FASBM
n = size(y,1);
m1 = size(y,2);
converge = 0;
threshold = 1e-5;
maxit_fbeta = 50;
iter_fbeta= 0;
maxit_beta = 100;


dataClass = superiorfloat(Xcov,y);
[~,~,~,ilinkFun] = stattestlink(linkArg,dataClass);
 
 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   Updating f
%%%%%%%%%%%%%%%%%%%%%%%%%%%%

while converge == 0 && iter_fbeta < maxit_fbeta
    iter_fbeta = iter_fbeta + 1;
    if  strcmp(ftype, 'non')
        xin = Pick(Xcov,[], [],[],[] ) * beta ;
        rands = randsample(length(xin),floor(length(xin)*frac));
        xou = sort(unique(xin(rands))); %  xou must be sorted , subsampling N points
        if m1==1
            cin = Pick(reshape(center(idx,idx),n,m1),[],[],[],[] );
        else
            cin = Pick(center(idx(1:n),idx) ,[],[],[],[] );
        end
        win = Pick(ones(n,m1) ,[],[],[],[] );
        yin = Pick(y,[],[],[],[] );
        [~,muv,mud]=LwlsG(bw,kernel,nwe,npoly,nder,xin,yin,win,xou,cin,linkArg,iter_fbeta,distriArg);
        muv = muv- interp1(xou, muv,floor(mean(xou)),'spline')    ;
    else
        muv =[];
        xou =[];
        mud =[];
    end
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %   Updating  beta(s*1)
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    if isempty(Xcov)        %f=0
        beta = 0;
    elseif size(Xcov, 2)==1 && strcmp(ftype, 'non') %f ='non' and s=1
        beta = 1;
    else   %f ='non' and s>1 ( Initialization using the last updated value)
        
        converge_beta = 0;
        iter_beta = 0;
        while converge_beta == 0 && iter_beta < maxit_beta;      
            beta_old = beta;
            iter_beta = iter_beta +1;
            Xreg = Pick(Xcov,[],[],[],[] );
            Yreg = Pick(y,[],[],[],[]);
            c_in  = pick(reshape(center(idx,idx),n,1),[],[],[],[]);
            eta =  Xreg*beta_old;
            eta2 = c_in  +  interp1(xou, muv, eta,'spline');
            mu = ilinkFun(eta2)  ;
            N = size(Yreg,1);
            d1 =  interp1(xou, mud, eta,'spline');
            D = sparse(1:N,1:N,d1);
            der = Xreg'*D;
            beta = Betaupd(beta_old, Yreg,der, mu,[],linkArg,distriArg) ;
            beta = beta/norm(beta);
            converge_beta = norm((beta -beta_old),1 )/(norm(beta_old,1 )) < threshold;
        end
        
        if ~converge_beta
            fprintf( ['iter_fbeta = ' num2str(iter_fbeta) 'beta does not converge  \n']);
        end
        
    end
    
    %     check convergence of f
    if isempty(Xcov)        %f=0
        beta = 0;
        converge = 1;
    elseif size(Xcov, 2)==1 && strcmp(ftype, 'non') %f ='non' and s=1
        beta = 1;
        converge = 1;
    else   %f ='non' and s>1
        rng('default')
        rng(12345)
        pickXcov = Pick( Xcov*beta,[],[],[],[] );
        sample = linspace(min(pickXcov),max(pickXcov),100);
        f_new = interp1(xou, muv,  sample ,'spline');
        if iter_fbeta ==1
            f_old = 0;
        else
            f_old = interp1(prexou, premuv,  sample,'spline');
        end
          converge = norm(f_new -f_old,1 )/(norm(f_old,1 )) < threshold;
        plot(xou,muv);
        hold on
        prexou = xou;
        premuv = muv;
    end
    
end

  if ~converge
        fprintf('iter_fbeta does not converge  \n');
  end
    
end






















