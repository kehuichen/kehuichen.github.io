MATLAB CODE for ``NODE FEATURES ADJUSTED STOCHASTIC BLOCK MODEL"

The main function is Quasifitv3.m.
To use this function, one needs to specify the distribution of the relational data (Bernoulli, Poisson or Normal),
and the number of assumed communities K. 
Detailed explanations of all the input arguments and output values can be found in Quasifitv3.m . 
Also see example.m 
 

Reference: Y.Zhang et.al ``Node Features adjusted Stochastic Block Model”.