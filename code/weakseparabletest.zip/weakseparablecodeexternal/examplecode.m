%%%%%%%%%%%%%%%%%%%%%%
%Load example data
load X.mat %A 20x20x100 array of data X_i(s,t), i=1,...,100, s=1,...,20, t=1,...,20

%%%%%%%%%%%%%%%%%%%%%%
%FVE procedure for determining P_n and K_n
Pnfull = 8; %Largest j such that the marginal projection scores \chi_{jk} can be reasonably considered nonzero.
Knfull = 8; %Largest k such that the marginal projection scores \chi_{jk} can be reasonably considered nonzero.
[Pn_FVE,Kn_FVE,FVE] = FVEproc(X,Pnfull,Knfull); %Determines P_n and K_n using the FVE procedure

%%%%%%%%%%%%%%%%%%%%%%
%Test for weak separability
test = 'chi2'; %Set to 'chi2' to use chi^2 type mixture approximation, set to 'emp' to use empirical bootstrap

Pn = [Pn_FVE,2,3,4];
Kn = [Kn_FVE,2,3,4];
%Pn and Kn should be row vectors of the same length, where the lth choice of
%(P_n,K_n) considered is (Pn(l),Kn(l))

testopts.Pnfull = 8; %Largest j such that the marginal projection scores \chi_{jk} can be reasonably considered nonzero. (Use when test = 'chi2')
testopts.Knfull = 8; %Largest k such that the marginal projection scores \chi_{jk} can be reasonably considered nonzero. (Use when test = 'chi2')
testopts.B = 1000; %Number of bootstrap re-samples (Use when test = 'emp')

[pvalue,teststat] = weakseptest(X,test,Pn,Kn,testopts); %Test for weak separability. Outputs the P-value, S_n, and FVE(P_n,K_n) for each choice of (P_n,K_n). 
%X is the dataset, defined as a 3D array where X(s,t,i) corresponds to X_i(s,t), i=1,...,n.

