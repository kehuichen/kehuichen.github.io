% [Pn,Kn,FVE] = FVEproc(X,Pnfull,Knfull)
% This function implements the FVE procedure (see Section 3.3 in the paper)
% Input: 
% X: The dataset, defined as a 3D array such that X(s,t,i) corresponds
%       to X_i(s,t), i=1,...,n.
% Pnfull: Largest j such that the marginal projection scores \chi_{jk}
%       can be reasonably considered nonzero. Must be <= to the number of 
%       s gridpoints. 
% Knfull: Largest k such that the marginal projection scores \chi_{jk}
%       can be reasonably considered nonzero. Must be <= to the number of 
%       t gridpoints. 

% Output: 
% Pn: The value of P_n selected by the FVE procedure
% Kn: The value of K_n selected by the FVE procedure
% FVE: The value of FVE(P_n,K_n) for P_n and K_n selected by the FVE procedure

function [Pn,Kn,FVE] = FVEproc(X,Pnfull,Knfull)

    FVEcutoff=.85; 
    good=0;
    while good==0 && FVEcutoff<.95
    FVEcutoff=FVEcutoff+.05;

    %Get estimated zeta values
    [psihat,phihat,~,~,Pn,Kn] = estimatepsis(X,Pnfull,Knfull,FVEcutoff);
    [zetamatrixest,~] = zetafrompsis(X,psihat,phihat);

    %FVE
    FVE=FVEcalcs(zetamatrixest,Pn,Kn,Pnfull,Knfull,X);

        if FVE >= .90
        good=1;
        end
    end
    

