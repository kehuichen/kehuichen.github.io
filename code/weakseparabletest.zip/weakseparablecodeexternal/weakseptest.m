% [pval,teststat] = weakseptest(X,test,Pn,Kn,testopts)
% This is the main function for the test of weak separability. 
% Reference: A test of weak separability for multi-way functional data,
% with application to brain connectivity studies
% by Brian Lynch and Kehui Chen
% This code only works for dense regular surface data. 
% The method developed in the paper could work for more flexible designs
% with a modified version of this code.

%Input: 
% X: The dataset, defined as a 3D array such that X(s,t,i) corresponds
%   to X_i(s,t), i=1,...,n.
% test: The test procedure. Set to 'chi2' to use chi^2 type mixture
%   approximation, set to 'emp' to use empirical bootstrap.
% Pn: The number of components P_n to consider, or a row vector of choices 
%   of P_n to consider.
% Kn: The number of components K_n to consider, or a row vector of choices
%   of K_n to consider.
%   Pn and Kn should be row vectors of the same length, where the lth value of
%   (P_n,K_n) considered is (Pn(l),Kn(l)).
% testopts: Additional options needed for certain test procedures
%   testopts.Pnfull: Largest j such that the marginal projection scores \chi_{jk}
%       can be reasonably considered nonzero. Must be <= to the number of 
%       s gridpoints. (Use when test = 'chi2')
%   testopts.Knfull: Largest k such that the marginal projection scores \chi_{jk}
%       can be reasonably considered nonzero. Must be <= to the number of 
%       t gridpoints. (Use when test = 'chi2')
%   testopts.B: Number of bootstrap re-samples. (Use when test = 'emp')

% Output: 
% pval: The P-value for the test (or row vector of P-values for all choices
%   of (P_n,K_n))
% teststat: The test statistic S_n (or row vector of S_n's for all choices
%   of (P_n,K_n))

function [pval,teststat] = weakseptest(X,test,Pn,Kn,testopts)

if strcmp(test,'chi2')
    
    Pnfull=testopts.Pnfull;
    Knfull=testopts.Knfull;
    
    %Estimate "all" eigenfunctions/eigenvalues
    [psihatfull,phihatfull,lambdahatfull,gammahatfull,~,~] = estimatepsis(X,Pnfull,Knfull,0);
    [~,chiestfull] = zetafrompsis(X,psihatfull,phihatfull);

    Jsize=size(Pn(:),1);
    pval=zeros(1,Jsize);
    teststat=zeros(1,Jsize);
    for j=1:Jsize
    lambdahat=lambdahatfull(1:Pn(j));
    gammahat=gammahatfull(1:Kn(j));    
    %chi-square type mixture test
    [teststat(j),pval(j)]=mixturechi2test(chiestfull,lambdahat,gammahat);
    end
    
elseif strcmp(test,'emp')
    %test using empirical bootstrap
    [teststat,pval] = empboottestcomb(X,Pn,Kn,testopts.B);

end


