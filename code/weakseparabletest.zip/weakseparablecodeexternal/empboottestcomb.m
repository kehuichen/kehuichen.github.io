function [nonstudempteststat,nonstudemppval] = empboottestcomb(y,J,K,B)

[~,~,n]=size(y);
Jsize=size(J(:),1);

[psi,phi,~,~,~,~] = estimatepsis(y,max(J),max(K),0);
nonstudempteststat=zeros(1,Jsize);
xicell=cell(1,Jsize);
for j=1:Jsize
[zetamatrix,~] = zetafrompsis(y,psi(:,1:J(j)),phi(:,1:K(j)));
[p,~]=size(zetamatrix);
Sigmaest = (1/n)*(zetamatrix*zetamatrix'); %sample covariance matrix of estimated scores
xi=Sigmaest(triu(true(p,p),1)); %vector of off-diagonal elements
xicell{j}=xi;
nonstudempteststat(j)=n*sum(xi.^2); %non studentized test statistic
end

nonstudempbootsum = zeros(1,Jsize);
for b=1:B
    yb = datasample(y,n,3); %resample data with replacement
    [psihat,phihat,~,~,~,~] = estimatepsis(yb,max(J),max(K),0);
    
    % change signs of bootstrap eigenfunctions to match those of
    % eigenfunctions from data
    for i=1:max(J)
        diff=sum((psi(:,i)-psihat(:,i)).^2);
        diffopp=sum((psi(:,i)+psihat(:,i)).^2);
        if diffopp<diff
            psihat(:,i)=-psihat(:,i);
        end
    end
    for i=1:max(K)
        diff=sum((phi(:,i)-phihat(:,i)).^2);
        diffopp=sum((phi(:,i)+phihat(:,i)).^2);
        if diffopp<diff
            phihat(:,i)=-phihat(:,i);
        end
    end
    
    nonstudempbootstat=zeros(1,Jsize);
    for j=1:Jsize
    [zetamatrixestb,~] = zetafrompsis(yb,psihat(:,1:J(j)),phihat(:,1:K(j))); %estimated scores from boostrap sample
    [p,~]=size(zetamatrixestb);
    Sigmaestb = (1/n)*(zetamatrixestb*zetamatrixestb'); 
    xib=Sigmaestb(triu(true(p,p),1));
    nonstudempbootstat(j)=n*sum((xib-xicell{j}).^2); %non studentized bootstrap test statistic
    end
    nonstudempbootsum = nonstudempbootsum + (nonstudempbootstat>nonstudempteststat);
end

nonstudemppval=nonstudempbootsum/B;