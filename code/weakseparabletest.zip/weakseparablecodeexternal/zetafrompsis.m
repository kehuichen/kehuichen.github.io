function [zetamatrixest,chiest] = zetafrompsis(y,psihat,phihat)

[mtps,mtpt,n]=size(y);
[~,Pest]=size(psihat);
[~,Kest]=size(phihat);
p=Pest*Kest;

%center data
ybar=mean(y,3); %sample mean
ybararray=repmat(ybar,[1,1,n]);
y=y-ybararray;

%estimate chi values
chiest=zeros(Pest,Kest,n);
for i=1:n
chiest(:,:,i) = psihat'*y(:,:,i)*phihat;
end

%Get estimated zetas from estimated chis
zetamatrixest=zeros(p,n);
for i=1:n
    zetamatrixest(:,i)=reshape(transpose(chiest(:,:,i)),p,1);
end
